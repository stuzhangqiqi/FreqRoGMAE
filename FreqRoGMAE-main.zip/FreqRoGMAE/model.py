import hashlib
from pathlib import Path
import os
import weakref

import torch
import torch.nn.functional as F
import torch.nn as nn
from torch_geometric.nn import (
    Linear,
    GCNConv,
    SAGEConv,
    GATConv,
    GINConv,
    GATv2Conv
)

from torch_sparse import SparseTensor

def to_sparse_tensor(edge_index, num_nodes):
    return SparseTensor.from_edge_index(
        edge_index, sparse_sizes=(num_nodes, num_nodes)
    ).to(edge_index.device)


def creat_gnn_layer(name, first_channels, second_channels, heads):
    if name == "sage":
        layer = SAGEConv(first_channels, second_channels)
    elif name == "gcn":
        layer = GCNConv(first_channels, second_channels)
    elif name == "gin":
        layer = GINConv(Linear(first_channels, second_channels), train_eps=True)
    elif name == "gat":
        layer = GATConv(-1, second_channels, heads=heads)
    elif name == "gat2":
        layer = GATv2Conv(-1, second_channels, heads=heads)
    else:
        raise ValueError(name)
    return layer


def create_input_layer(num_nodes, num_node_feats,
                       use_node_feats=True, node_emb=None):
    emb = None
    if use_node_feats:
        input_dim = num_node_feats
        if node_emb:
            emb = torch.nn.Embedding(num_nodes, node_emb)
            input_dim += node_emb
    else:
        emb = torch.nn.Embedding(num_nodes, node_emb)
        input_dim = node_emb
    return input_dim, emb


def creat_activation_layer(activation):
    if activation is None:
        return nn.Identity()
    elif activation == "relu":
        return nn.ReLU()
    elif activation == "elu":
        return nn.ELU()
    else:
        raise ValueError("Unknown activation")


class GNNEncoder(nn.Module):
    def __init__(
            self,
            in_channels,
            hidden_channels,
            out_channels,
            num_layers=2,
            dropout=0.5,
            bn=False,
            layer="gcn",
            activation="elu",
            use_node_feats=True,
            num_nodes=None,
            node_emb=None,
    ):

        super().__init__()
        self.convs = nn.ModuleList()
        self.bns = nn.ModuleList()
        bn = nn.BatchNorm1d if bn else nn.Identity
        self.use_node_feats = use_node_feats
        self.node_emb = node_emb
        self.enc_mask_token = nn.Parameter(torch.zeros(1, in_channels))

        if node_emb is not None and num_nodes is None:
            raise RuntimeError("Please provide the argument `num_nodes`.")

        in_channels, self.emb = create_input_layer(
            num_nodes, in_channels, use_node_feats=use_node_feats, node_emb=node_emb
        )
        for i in range(num_layers):
            first_channels = in_channels if i == 0 else hidden_channels
            second_channels = out_channels if i == num_layers - 1 else hidden_channels
            heads = 1 if i == num_layers - 1 or 'gat' not in layer else 4

            self.convs.append(creat_gnn_layer(layer, first_channels, second_channels, heads))
            self.bns.append(bn(second_channels * heads))

        self.dropout = nn.Dropout(dropout)
        self.activation = creat_activation_layer(activation)

    def reset_parameters(self):
        for conv in self.convs:
            conv.reset_parameters()

        for bn in self.bns:
            if not isinstance(bn, nn.Identity):
                bn.reset_parameters()

        if self.emb is not None:
            nn.init.xavier_uniform_(self.emb.weight)

    def create_input_feat(self, x):
        if self.use_node_feats:
            input_feat = x
            if self.node_emb:
                input_feat = torch.cat([self.emb.weight, input_feat], dim=-1)
        else:
            input_feat = self.emb.weight
        return input_feat

    def forward(self, x, edge_index):
        x = self.create_input_feat(x)
        edge_index = to_sparse_tensor(edge_index, x.size(0))

        for i, conv in enumerate(self.convs[:-1]):
            x = self.dropout(x)
            x = conv(x, edge_index)
            x = self.bns[i](x)
            x = self.activation(x)
        x = self.dropout(x)
        x = self.convs[-1](x, edge_index)
        x = self.bns[-1](x)
        x = self.activation(x)
        return x

    @torch.no_grad()
    def get_embedding(self, x, edge_index, mode="cat"):

        self.eval()
        assert mode in {"cat", "last"}, mode

        x = self.create_input_feat(x)
        edge_index = to_sparse_tensor(edge_index, x.size(0))
        out = []
        for i, conv in enumerate(self.convs[:-1]):
            x = self.dropout(x)
            x = conv(x, edge_index)
            x = self.bns[i](x)
            x = self.activation(x)
            out.append(x)
        x = self.dropout(x)
        x = self.convs[-1](x, edge_index)
        x = self.bns[-1](x)
        x = self.activation(x)
        out.append(x)

        if mode == "cat":
            embedding = torch.cat(out, dim=1)
        else:
            embedding = out[-1]

        return embedding


# 在 model.py 中添加以下类
class GraphMAEStudent(nn.Module):
    """学生模型：基于graph的MAE，只做特征掩码重建，使用GAT编码器"""

    def __init__(
            self,
            in_channels,
            hidden_channels,
            out_channels,
            num_layers=2,
            dropout=0.5,
            bn=False,
            layer="gat",  # 默认改为gat
            activation="elu",
            mask_rate: float = 0.5,
            loss_fn: str = "mse",
            heads: int = 4,  # GAT特有的多头注意力参数
    ):
        super().__init__()
        # 编码器使用GAT架构
        self.encoder = Encoder_fea(
            in_channels=in_channels,
            hidden_channels=hidden_channels,
            out_channels=out_channels,
            num_layers=num_layers,
            dropout=dropout,
            bn=bn,
            layer=layer,  # 这里传入layer参数
            activation=activation,
            use_node_feats=True,
            num_nodes=None,
            node_emb=None,
            heads=heads,
        )

        # 特征解码器（重建原始特征）
        self.feature_decoder = FeatureDecoder(
            in_channels=in_channels,
            hidden_channels=hidden_channels,
            out_channels=out_channels,
        )

        self._mask_rate = mask_rate
        self.enc_mask_token = nn.Parameter(torch.zeros(1, in_channels))


        if loss_fn == "mse":
            self.criterion = nn.MSELoss()
        # else:
        #     self.criterion = nn.MSELoss()  # 默认使用MSE

    def reset_parameters(self):
        self.encoder.reset_parameters()
        self.feature_decoder.reset_parameters()
        nn.init.xavier_normal_(self.enc_mask_token)

    def forward(self, x, edge_index):
        """推理时返回编码器输出"""
        return self.encoder(x, edge_index)

    def encoding_mask_noise(self, x, mask_rate=0.5):
        """掩码特征并添加掩码token"""
        num_nodes = x.shape[0]
        perm = torch.randperm(num_nodes, device=x.device)

        # 要掩码的节点数
        num_mask_nodes = int(mask_rate * num_nodes)
        mask_nodes = perm[:num_mask_nodes]
        keep_nodes = perm[num_mask_nodes:]

        # 创建掩码后的特征
        out_x = x.clone()
        out_x[mask_nodes] = 0.0  # 将掩码节点特征设为0
        out_x[mask_nodes] += self.enc_mask_token  # 加上掩码token

        return out_x, mask_nodes

    @torch.no_grad()
    def get_embeddings(self, x, edge_index):
        """获取节点嵌入"""
        self.eval()
        return self.encoder(x, edge_index)

class Encoder_fea(nn.Module):
    def __init__(
            self,
            in_channels,
            hidden_channels,
            out_channels,
            num_layers=2,
            dropout=0.5,
            bn=False,
            layer="gcn",
            activation="elu",
            use_node_feats=True,
            num_nodes=None,
            node_emb=None,
            heads=1,
    ):

        super().__init__()
        self.convs = nn.ModuleList()
        self.bns = nn.ModuleList()
        bn = nn.BatchNorm1d if bn else nn.Identity
        self.use_node_feats = use_node_feats
        self.node_emb = node_emb
        self.enc_mask_token = nn.Parameter(torch.zeros(1, in_channels))

        if node_emb is not None and num_nodes is None:
            raise RuntimeError("Please provide the argument `num_nodes`.")

        in_channels, self.emb = create_input_layer(
            num_nodes, in_channels, use_node_feats=use_node_feats, node_emb=node_emb
        )

        # GAT 模式检查
        is_gat = 'gat' in layer.lower()
        # 当前层输入通道数初始化为 in_channels
        current_channels = in_channels

        for i in range(num_layers):
            first_channels = current_channels
            second_channels = out_channels if i == num_layers - 1 else hidden_channels

            # 修正 2：如果使用 GAT 且不是最后一层，则使用多头；最后一层必须使用 1 个头来合并结果
            layer_heads = 1
            if is_gat:
                layer_heads = 1 if i == num_layers - 1 else heads

            # 修正 3：创建 GNN 层
            self.convs.append(creat_gnn_layer(layer, first_channels, second_channels, layer_heads))

            # 计算当前层的输出通道数
            if is_gat and i < num_layers - 1:
                # GAT 中间层：输出通道数 = hidden_channels * heads
                output_channels = second_channels * layer_heads
            else:
                # GCN, SAGE, GIN 或 GAT 最后一层：输出通道数 = second_channels
                output_channels = second_channels

            # 修正 4：设置 BatchNorm 的输入通道数，并更新下一层的输入通道数
            self.bns.append(bn(output_channels))
            current_channels = output_channels  # 更新下一层的输入通道

        self.dropout = nn.Dropout(dropout)
        self.activation = creat_activation_layer(activation)

    def reset_parameters(self):
        for conv in self.convs:
            conv.reset_parameters()

        for bn in self.bns:
            if not isinstance(bn, nn.Identity):
                bn.reset_parameters()

        if self.emb is not None:
            nn.init.xavier_uniform_(self.emb.weight)

    def create_input_feat(self, x):
        if self.use_node_feats:
            input_feat = x
            if self.node_emb:
                input_feat = torch.cat([self.emb.weight, input_feat], dim=-1)
        else:
            input_feat = self.emb.weight
        return input_feat

    def forward(self, x, edge_index):
        x = self.create_input_feat(x)
        edge_index = to_sparse_tensor(edge_index, x.size(0))

        for i, conv in enumerate(self.convs[:-1]):
            x = self.dropout(x)
            x = conv(x, edge_index)
            x = self.bns[i](x)
            x = self.activation(x)
        x = self.dropout(x)
        x = self.convs[-1](x, edge_index)
        x = self.bns[-1](x)
        x = self.activation(x)
        return x

    @torch.no_grad()
    def get_embedding(self, x, edge_index, mode="cat"):

        self.eval()
        assert mode in {"cat", "last"}, mode

        x = self.create_input_feat(x)
        edge_index = to_sparse_tensor(edge_index, x.size(0))
        out = []
        for i, conv in enumerate(self.convs[:-1]):
            x = self.dropout(x)
            x = conv(x, edge_index)
            x = self.bns[i](x)
            x = self.activation(x)
            out.append(x)
        x = self.dropout(x)
        x = self.convs[-1](x, edge_index)
        x = self.bns[-1](x)
        x = self.activation(x)
        out.append(x)

        if mode == "cat":
            embedding = torch.cat(out, dim=1)
        else:
            embedding = out[-1]

        return embedding



class DotEdgeDecoder(nn.Module):
    """Simple Dot Product Edge Decoder"""

    def __init__(self, *args, **kwargs):
        super().__init__()

    def reset_parameters(self):
        return

    def forward(self, z, edge, sigmoid=True):
        x = z[edge[0]] * z[edge[1]]
        x = x.sum(-1)

        if sigmoid:
            return x.sigmoid()
        else:
            return x


class EdgeDecoder(nn.Module):
    """Simple MLP Edge Decoder"""

    def __init__(
            self, in_channels, hidden_channels, out_channels=1,
            num_layers=2, dropout=0.5, activation='relu'
    ):

        super().__init__()
        self.mlps = nn.ModuleList()

        for i in range(num_layers):
            first_channels = in_channels if i == 0 else hidden_channels
            second_channels = out_channels if i == num_layers - 1 else hidden_channels
            self.mlps.append(nn.Linear(first_channels, second_channels))

        self.dropout = nn.Dropout(dropout)
        self.activation = creat_activation_layer(activation)

    def reset_parameters(self):
        for mlp in self.mlps:
            mlp.reset_parameters()

    def forward(self, z, edge, sigmoid=True, reduction=False):
        x = z[edge[0]] * z[edge[1]]

        if reduction:
            x = x.mean(1)

        for i, mlp in enumerate(self.mlps[:-1]):
            x = self.dropout(x)
            x = mlp(x)
            x = self.activation(x)

        x = self.mlps[-1](x)

        if sigmoid:
            return x.sigmoid()
        else:
            return x


class DegreeDecoder(nn.Module):
    """Simple MLP Degree Decoder"""

    def __init__(
            self, in_channels, hidden_channels, out_channels=1,
            num_layers=2, dropout=0.5, activation='relu',
    ):

        super().__init__()
        self.mlps = nn.ModuleList()

        for i in range(num_layers):
            first_channels = in_channels if i == 0 else hidden_channels
            second_channels = out_channels if i == num_layers - 1 else hidden_channels
            self.mlps.append(nn.Linear(first_channels, second_channels))

        self.dropout = nn.Dropout(dropout)
        self.activation = creat_activation_layer(activation)

    def reset_parameters(self):
        for mlp in self.mlps:
            mlp.reset_parameters()

    def forward(self, x):

        for i, mlp in enumerate(self.mlps[:-1]):
            x = mlp(x)
            x = self.dropout(x)
            x = self.activation(x)

        x = self.mlps[-1](x)
        x = self.activation(x)

        return x


def random_negative_sampler(edge_index, num_nodes, num_neg_samples):
    neg_edges = torch.randint(0, num_nodes, size=(2, num_neg_samples)).to(edge_index)
    return neg_edges

class prediction_MLP(nn.Module):
    def __init__(self, in_dim, hidden_dim, out_dim):  # bottleneck structure
        super().__init__()

        self.layer1 = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(inplace=True)
        )
        self.layer2 = nn.Linear(hidden_dim, out_dim)

    def forward(self, x):
        x = self.layer1(x)
        x = self.layer2(x)
        return x

class FeatureDecoder(nn.Module):
    def __init__(
        self, in_channels, hidden_channels, out_channels):
        super().__init__()
        self.mlps = nn.ModuleList()

        self.p_1 = prediction_MLP(out_channels, hidden_channels, in_channels)

    def forward(self, z):
        recon_x = self.p_1(z)
        return recon_x
# ═══════════════════════════════════════════════════════════════════════════════
# FreqRobustGMAE  (v2)
# 在 v1 基础上加入：
#   1) HaarFramelet 用稀疏传播替代懒初始化 GCN，消除设备/稳定性问题
#   2) kNN 特征图作为由特征构建的结构先验，混合进多尺度分支
#   3) 重建目标解耦：低频分支重建平滑特征，高频分支重建残差，框架分支重建原始特征
#   4) 边置信度软加权（ChebConv 传入 edge_weight），替代硬阈值删边
#   5) 重新设计的对比损失：正对 = 同节点在 kNN视角 / 攻击视角 下的表示
#      （而非同图上不同分支的表示，语义更清晰、更贴合鲁棒性目标）
#   6) BCE 负对使用随机采样并尝试排除 kNN 邻居
# ═══════════════════════════════════════════════════════════════════════════════

from FreqRoGMAE.loss import freq_infonce_loss, freq_bce_loss, freq_recon_loss
from torch_geometric.nn import ChebConv, knn_graph
from torch_geometric.nn.conv.gcn_conv import gcn_norm
from torch_geometric.utils import to_undirected


def sparse_propagate(x: torch.Tensor, edge_index: torch.Tensor,
                     num_nodes: int, edge_weight: torch.Tensor = None,
                     add_self_loops: bool = True) -> torch.Tensor:
    """
    无状态的稀疏传播：out = Â x，Â 为归一化邻接（含自环）。
    替代此前散落在 ChebyshevFilter / HaarFramelet 中的懒初始化 GCNConv，
    不持有任何参数，不依赖模块状态，天然支持任意 device。
    """
    edge_index_norm, gcn_weight = gcn_norm(
        edge_index, edge_weight=edge_weight,
        num_nodes=num_nodes, add_self_loops=add_self_loops)
    row, col = edge_index_norm
    if os.environ.get("FREQROGMAE_SPARSE_MATMUL") == "1":
        adj = SparseTensor(row=row, col=col, value=gcn_weight,
                           sparse_sizes=(num_nodes, num_nodes))
        return adj.matmul(x)
    out = torch.zeros_like(x)
    out.index_add_(0, row, x[col] * gcn_weight.unsqueeze(-1))
    return out


def cheb_conv_sparse(conv: ChebConv, x: torch.Tensor,
                     edge_index: torch.Tensor,
                     edge_weight: torch.Tensor = None) -> torch.Tensor:
    """Same ChebConv recurrence using sparse matrix products for large graphs."""
    n = x.size(0)
    normalized_edges, norm = conv.__norm__(
        edge_index, n, edge_weight, conv.normalization,
        lambda_max=None, dtype=x.dtype, batch=None,
    )
    adj = SparseTensor(row=normalized_edges[1], col=normalized_edges[0],
                       value=norm, sparse_sizes=(n, n))
    tx_0 = x
    out = conv.lins[0](tx_0)
    if len(conv.lins) > 1:
        tx_1 = adj.matmul(x)
        out = out + conv.lins[1](tx_1)
        for lin in conv.lins[2:]:
            tx_2 = 2.0 * adj.matmul(tx_1) - tx_0
            out = out + lin(tx_2)
            tx_0, tx_1 = tx_1, tx_2
    if conv.bias is not None:
        out = out + conv.bias
    return out


class HaarFramelet(nn.Module):
    """
    多层 Haar-type framelet 分解（Branch III 核心滤波器），并行版本。
    Haar filter bank:  â(x) = cos(x/2),  b̂(x) = sin(x/2)
    一阶 Chebyshev 近似：低通 ≈ (I+Â)/2，高通 ≈ (I-Â)/2。

    与递归版本的区别（修复过平滑问题）：
    递归版本每一层都对上一层已经平滑过的 cur 继续平滑，J 越大等价于
    施加了 J 次连续低通，导致所有"高频"分量实际上都退化成不同程度的
    低频，多频差异性被消耗掉（这是 K=7,J=5 比 K=3,J=2 更差的根因）。

    并行版本：每一层都对同一个多跳累积平滑量 agg 取残差，hi_j 表示
    "j 跳平滑之后还剩下的高频成分"，层与层之间是渐进式扩大感受野，
    而不是重复施加平滑，因此 J 增大代表获取更多尺度的残差信息，
    而不是更强的整体模糊化。
    """

    def __init__(self, in_channels: int, J: int = 2):
        super().__init__()
        self.J = J
        self.theta = nn.Parameter(torch.ones(1 + J) / (1 + J))

    def forward(self, x: torch.Tensor, edge_index,
               edge_weight: torch.Tensor = None) -> torch.Tensor:
        components = []
        agg = x
        for _ in range(self.J):
            agg = sparse_propagate(agg, edge_index, x.size(0), edge_weight)  # 多跳累积平滑
            hi = x - agg                                                     # 该尺度的高频残差
            components.append(hi)
        components.append(agg)          # 最终多跳平滑 = 最粗尺度低频
        components = components[::-1]   # [低频(最粗), 高频-1(最细), ..., 高频-J(最粗)]
        theta = torch.softmax(self.theta, dim=0)
        out = sum(theta[i] * components[i] for i in range(len(components)))
        return out


class FreqBranchEncoder(nn.Module):
    """
    Branch I / II：Chebyshev 多项式滤波编码器（低通 / 高通）。
    使用 PyG 内置 ChebConv 保证数值稳定性；通过权重初始化注入频率先验，
    并通过对比/重建损失在训练中进一步分化。
    支持 edge_weight，用于边置信度软加权。
    """

    def __init__(self, in_channels, out_channels, K=3,
                mode="low", dropout=0.5):
        super().__init__()
        self.conv = ChebConv(in_channels, out_channels, K=K)
        self.skip = nn.Linear(in_channels, out_channels, bias=False)
        self.bn = nn.BatchNorm1d(out_channels)
        self.dropout = nn.Dropout(dropout)
        self.mode = mode
        self.K = K
        self._init_freq_bias(mode)

    def _init_freq_bias(self, mode):
        """用频率先验初始化权重，引导低/高通方向。"""
        with torch.no_grad():
            if mode == "low":
                for k, lin in enumerate(self.conv.lins):
                    nn.init.xavier_uniform_(lin.weight)
                    lin.weight.data *= (0.5 ** k)
            elif mode == "high":
                for k, lin in enumerate(self.conv.lins):
                    nn.init.xavier_uniform_(lin.weight)
                    lin.weight.data *= (1.2 ** k) / (k + 1)

    def reset_parameters(self):
        self.conv.reset_parameters()
        self.skip.reset_parameters()
        self.bn.reset_parameters()
        self._init_freq_bias(self.mode)

    def forward(self, x, edge_index, edge_weight=None):
        x_in = self.dropout(x)
        if os.environ.get("FREQROGMAE_SPARSE_MATMUL") == "1":
            h = cheb_conv_sparse(self.conv, x_in, edge_index, edge_weight)
        else:
            h = self.conv(x_in, edge_index, edge_weight=edge_weight)
        h = h + self.skip(x_in)     # 残差，缓解高阶 Chebyshev 多项式的过平滑
        h = self.bn(h)
        return F.elu(h)


class FrameBranchEncoder(nn.Module):
    """
    Branch III：HaarFramelet 滤波 + MLP 投影。
    支持 edge_weight 透传到内部滤波器。
    """

    def __init__(self, in_channels: int, out_channels: int,
                filter_module: HaarFramelet, dropout: float = 0.5):
        super().__init__()
        self.filter = filter_module
        self.proj = nn.Sequential(
            nn.Linear(in_channels, out_channels),
            nn.ELU(),
            nn.Dropout(dropout),
            nn.Linear(out_channels, out_channels),
        )
        self.bn = nn.BatchNorm1d(out_channels)

    def reset_parameters(self):
        for m in self.proj:
            if hasattr(m, "reset_parameters"):
                m.reset_parameters()
        self.bn.reset_parameters()
        self.filter.theta.data.fill_(1.0 / (1 + self.filter.J))

    def forward(self, x: torch.Tensor, edge_index,
               edge_weight: torch.Tensor = None) -> torch.Tensor:
        h = self.filter(x, edge_index, edge_weight=edge_weight)
        h = self.proj(h)
        h = self.bn(h)
        return F.elu(h)


class FreqRobustGMAE(nn.Module):
    """
    FreqRobustGMAE (v2)：多频滤波 + 图掩码自编码器 + 特征 kNN 结构先验
    + 解耦重建目标 + 跨视角对比学习。

    三分支：
      low_enc   — 低通 ChebConv 编码器
      high_enc  — 高通 ChebConv 编码器
      frame_enc — Haar Framelet 多频融合编码器

    低/高频分支在两套结构视角下各算一次；完整模型的多尺度分支
    默认只在 knn 视角下参与预训练的损失：
      "knn视角" — 基于特征 k-NN 图（由特征构建的结构先验）
      "atk视角" — 原始（可能被攻击的）图

    损失：
      L_recon      — 三分支独立重建（低频→平滑特征，高频→残差默认目标，
                    framelet→原始特征），均在 knn视角 下计算
      L_infonce    — 低/高频分支在 knn视角 vs atk视角 下的跨视角对比；
                    多尺度分支仅在显式启用 multiscale_cross_view 后参与
      L_bce        — 伪标签 BCE，使用尝试排除 kNN 邻居的随机负对
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        mask=None,
        mask_rate: float = 0.5,
        K: int = 3,
        J: int = 2,
        dropout: float = 0.5,
        knn_k: int = 10,
        edge_conf_threshold: float = 0.3,
        lambda_c: float = 0.5,
        lambda_b: float = 0.5,
        # lambda_r: float = 0.1,
        temperature: float = 0.5,
        ablation: str = "full",
        fusion_rule: str = "paper",
        multiscale_cross_view: bool = False,
        multiscale_inference: str = "fused",
        strict_negatives: bool = False,
        high_recon_target: str = "residual",
        edge_weight_mode: str = "confidence",
    ):
        super().__init__()
        valid_ablations = {
            "full", "wo_knn", "wo_ec", "lp_only",
            "wo_high", "wo_ms", "wo_nce", "wo_bce", "wo_af",
            "high_only", "ms_only", "three_lp",
        }
        if ablation not in valid_ablations:
            raise ValueError(
                f"Unknown ablation '{ablation}'. "
                f"Expected one of {sorted(valid_ablations)}."
            )
        if fusion_rule not in {"paper", "linear_half_minus_rho"}:
            raise ValueError(
                "fusion_rule must be 'paper' or 'linear_half_minus_rho'"
            )
        if multiscale_inference not in {"fused", "knn_only"}:
            raise ValueError(
                "multiscale_inference must be 'fused' or 'knn_only'"
            )
        if high_recon_target not in {"residual", "smooth"}:
            raise ValueError(
                "high_recon_target must be 'residual' or 'smooth'"
            )
        if edge_weight_mode not in {"confidence", "uniform_half"}:
            raise ValueError(
                "edge_weight_mode must be 'confidence' or 'uniform_half'"
            )
        self.mask = mask
        self._mask_rate = mask_rate
        self.knn_k = knn_k
        self.edge_conf_threshold = edge_conf_threshold
        self.ablation = ablation
        self.fusion_rule = fusion_rule
        self.multiscale_cross_view = multiscale_cross_view
        self.multiscale_inference = multiscale_inference
        self.strict_negatives = strict_negatives
        self.high_recon_target = high_recon_target
        self.edge_weight_mode = edge_weight_mode
        self.use_knn_view = ablation != "wo_knn"
        self.use_edge_confidence = ablation != "wo_ec"
        self.use_low_branch = ablation not in {"high_only", "ms_only"}
        self.use_high_branch = ablation not in {
            "lp_only", "wo_high", "ms_only",
        }
        self.use_frame_branch = ablation not in {
            "lp_only", "wo_ms", "high_only",
        }
        self.three_lp = ablation == "three_lp"
        self.fixed_knn_weight = 0.5 if ablation == "wo_af" else None
        self.lambda_c = 0.0 if ablation == "wo_nce" else lambda_c
        self.lambda_b = 0.0 if ablation == "wo_bce" else lambda_b
        # self.lambda_r = lambda_r
        self.temperature = temperature

        self.enc_mask_token = nn.Parameter(torch.zeros(1, in_channels))

        self.low_enc = FreqBranchEncoder(
            in_channels=in_channels, out_channels=out_channels,
            K=K, mode="low", dropout=dropout)

        self.high_enc = FreqBranchEncoder(
            in_channels=in_channels, out_channels=out_channels,
            K=K, mode="low" if self.three_lp else "high", dropout=dropout)

        if self.three_lp:
            # Branch-count control (not parameter matched): replace the
            # high-pass and multiscale encoders with two additional low-pass
            # Chebyshev encoders while retaining three output branches.
            self.frame_enc = FreqBranchEncoder(
                in_channels=in_channels, out_channels=out_channels,
                K=K, mode="low", dropout=dropout)
        else:
            self.frame_enc = FrameBranchEncoder(
                in_channels=in_channels, out_channels=out_channels,
                filter_module=HaarFramelet(in_channels, J=J), dropout=dropout)

        self.alpha = nn.Parameter(torch.tensor(0.5))
        self.beta  = nn.Parameter(torch.tensor(0.5))
        self.fusion_proj = nn.Sequential(
            nn.Linear(out_channels * 2, out_channels),
            nn.ELU(),
            nn.Linear(out_channels, out_channels),
        )

        self.dec_low   = nn.Linear(out_channels, in_channels)
        self.dec_high  = nn.Linear(out_channels, in_channels)
        self.dec_frame = nn.Linear(out_channels, in_channels)

        self.bce_clf = nn.Sequential(
            nn.Linear(out_channels * 2, out_channels),
            nn.ReLU(),
            nn.Linear(out_channels, 1),
        )

        self._in_channels = in_channels
        self._out_channels = out_channels

        # Exclude inactive branch parameters from optimizer/model-size counts.
        # This does not change the forward computation of existing variants.
        if not self.use_low_branch:
            for module in (self.low_enc, self.dec_low):
                for parameter in module.parameters():
                    parameter.requires_grad_(False)
        if not self.use_high_branch:
            for module in (self.high_enc, self.dec_high):
                for parameter in module.parameters():
                    parameter.requires_grad_(False)
        if not self.use_frame_branch:
            for module in (self.frame_enc, self.dec_frame):
                for parameter in module.parameters():
                    parameter.requires_grad_(False)

        # 缓存 kNN 图（同一张图在多个 epoch 间结构不变，避免重复计算）
        self._cached_knn_edge = None
        self._cached_knn_key = None
        self._cached_knn_x_ref = None
        self._knn_k_calibrated = False

    # ──────────────────────────────────────────────────────────
    # 工具方法
    # ──────────────────────────────────────────────────────────

    def reset_parameters(self):
        self.low_enc.reset_parameters()
        self.high_enc.reset_parameters()
        self.frame_enc.reset_parameters()
        for m in self.fusion_proj:
            if hasattr(m, "reset_parameters"):
                m.reset_parameters()
        self.dec_low.reset_parameters()
        self.dec_high.reset_parameters()
        self.dec_frame.reset_parameters()
        for m in self.bce_clf:
            if hasattr(m, "reset_parameters"):
                m.reset_parameters()
        nn.init.zeros_(self.enc_mask_token)
        self.alpha.data.fill_(0.5)
        self.beta.data.fill_(0.5)
        self._cached_knn_edge = None
        self._cached_knn_key = None
        self._cached_knn_x_ref = None
        self._knn_k_calibrated = False

    def encoding_mask_noise(self, x: torch.Tensor, mask_rate: float):
        """随机掩码节点特征，与 GraphMAE 保持一致。"""
        N = x.size(0)
        perm = torch.randperm(N, device=x.device)
        n_mask = int(mask_rate * N)
        mask_nodes = perm[:n_mask]
        out_x = x.clone()
        out_x[mask_nodes] = 0.0
        out_x[mask_nodes] += self.enc_mask_token
        return out_x, mask_nodes

    def _fuse(self, z_l: torch.Tensor, z_h: torch.Tensor) -> torch.Tensor:
        z1 = F.elu(self.alpha * z_l + self.beta * z_h)
        z1 = F.normalize(z1, p=2, dim=-1)
        return z1

    def get_knn_edge(self, x: torch.Tensor,
                    edge_index: torch.Tensor = None) -> torch.Tensor:
        """
        基于特征余弦相似度构建 k-NN 图，作为由特征导出的结构先验。
        内存缓存用张量身份与版本快速命中；首次磁盘查找则使用特征内容
        的稳定哈希，避免不同特征矩阵因形状相同而复用错误的 kNN 图。

        若传入 edge_index，且当前未显式校准过 k，则用原图的平均度数自动
        校正 knn_k（四舍五入，至少为 2）。这是为了修复 overlap_ratio 的
        尺度失配问题：此前固定 knn_k=10，而 Cora 真实图平均度数约为 3.9，
        kNN 图密度是原图的 2.5 倍以上，导致 overlap_ratio 在 clean/attacked
        两种情况下都被天然压低且区分度很小（实测 0.21 vs 0.18），这个差异
        主要来自密度失配而非攻击本身。自动按平均度数校准后，两套图的密度
        量级才具有可比性；overlap_ratio 仍只是原图与特征结构一致性的代理量。
        """
        if edge_index is not None and not getattr(self, "_knn_k_calibrated", False):
            avg_degree = edge_index.size(1) / max(x.size(0), 1)
            self.knn_k = max(2, round(avg_degree))
            # self.knn_k = 20
            self._knn_k_calibrated = True
            print(f"[knn_k auto-calibrated] avg_degree={avg_degree:.2f} → knn_k={self.knn_k}")

        key = (x._version, tuple(x.shape), str(x.dtype),
               str(x.device), self.knn_k)
        if (self._cached_knn_key == key
                and self._cached_knn_x_ref is not None
                and self._cached_knn_x_ref() is x
                and self._cached_knn_edge is not None):
            return self._cached_knn_edge

        # Hash once per distinct tensor/version. Legacy shape-only cache files
        # are intentionally ignored because their source features are unknown.
        x_cpu = x.detach().contiguous().cpu()
        feature_hash = hashlib.sha256()
        feature_hash.update(str(x_cpu.dtype).encode("ascii"))
        feature_hash.update(str(tuple(x_cpu.shape)).encode("ascii"))
        feature_hash.update(memoryview(x_cpu.view(torch.uint8).numpy()))
        feature_digest = feature_hash.hexdigest()
        disk_cache_dir = Path("data/knn_cache")
        disk_cache_path = disk_cache_dir / (
            f"knn_n{x.size(0)}_d{x.size(1)}_k{self.knn_k}_x{feature_digest}.pt"
        )
        if disk_cache_path.exists():
            edge_index_knn = torch.load(
                disk_cache_path, map_location="cpu", weights_only=True
            ).to(x.device)
            self._cached_knn_edge = edge_index_knn
            self._cached_knn_key = key
            self._cached_knn_x_ref = weakref.ref(x)
            print(f"[knn disk cache] loaded {disk_cache_path}")
            return edge_index_knn

        # Build the cached kNN topology on CPU. Some torch-cluster builds can
        # trigger an asynchronous illegal-memory-access error in the CUDA kNN
        # kernel; the following edge-confidence operation then appears in the
        # traceback even though it is not the source of the failure. For the
        # transductive datasets used here, kNN construction happens only once
        # per run, so the CPU path is stable with negligible epoch-wise cost.
        x_norm_cpu = F.normalize(
            x_cpu.float(), p=2, dim=-1
        ).contiguous()
        edge_index_knn = knn_graph(
            x_norm_cpu,
            k=self.knn_k,
            loop=False,
            flow="source_to_target",
        )
        edge_index_knn = to_undirected(edge_index_knn, num_nodes=x.size(0))
        disk_cache_dir.mkdir(parents=True, exist_ok=True)
        torch.save(edge_index_knn, disk_cache_path)
        print(f"[knn disk cache] saved {disk_cache_path}")
        edge_index_knn = edge_index_knn.to(x.device)

        self._cached_knn_edge = edge_index_knn
        self._cached_knn_key = key
        self._cached_knn_x_ref = weakref.ref(x)
        return edge_index_knn

    def edge_confidence(self, x: torch.Tensor,
                        edge_index: torch.Tensor) -> torch.Tensor:
        """
        边置信度软加权（分布相对版）。

        之前的实现用固定阈值 edge_conf_threshold=0.3 和 sigmoid(8*(sim-0.3))，
        但 Cora 这类 bag-of-words 特征的真实边平均余弦相似度本来就只有
        0.2~0.3 量级（论文共享少量词汇是正常的，不代表异常），导致 clean 图
        和攻击图算出来的 mean_conf 几乎没有区分度（实测 0.2788 vs 0.2591），
        clamp 后两者都被压到同一个上限，自适应机制完全失效。

        改为基于当前图自身相似度分布的 z-score 标准化：不再问"这条边的
        相似度是否超过绝对阈值 0.3"，而是问"这条边的相似度相对于本图
        全部边的相似度分布，处于多少个标准差的位置"。这样无论 clean 图
        还是攻击图，confidence 的分布形状会自动适配该图的真实统计特性，
        而值的相对高低则能反映出"这条边在本图里是否异常"。
        """
        if self.edge_weight_mode == "uniform_half":
            # Experimental fixed-magnitude control. This tests whether the
            # feature-relative ordering of observed edges matters beyond the
            # roughly one-half overall propagation scale of sigmoid scores.
            return torch.full(
                (edge_index.size(1),), 0.5, dtype=x.dtype, device=x.device
            )
        row, col = edge_index
        if os.environ.get("FREQROGMAE_SPARSE_MATMUL") == "1":
            # Keep only one edge-feature block in memory on large graphs.
            block = 8192
            sim = torch.cat([
                F.cosine_similarity(x[row[start:start + block]],
                                    x[col[start:start + block]], dim=1)
                for start in range(0, row.numel(), block)
            ])
        else:
            sim = F.cosine_similarity(x[row], x[col], dim=1)
        mean_sim = sim.mean()
        std_sim  = sim.std().clamp(min=1e-4)
        z = (sim - mean_sim) / std_sim
        weight = torch.sigmoid(z)   # 高于本图平均相似度的边 → 高置信度
        return weight

    def estimate_attack_strength(self, x: torch.Tensor,
                                 edge_index: torch.Tensor) -> torch.Tensor:
        """
        攻击强度的代理指标，用于决定 get_embedding 中 kNN 视角的融合权重。

        z-score 归一化后的 edge_confidence 均值天然会趋近 sigmoid(0)=0.5
        （标准化后正负抵消），不再能用来区分 clean/attacked，因此这里改用
        一个独立的、更直接的攻击信号：图结构与特征空间 kNN 结构的重合率。

        重合率 = |原图边集合 ∩ kNN边集合| / |原图边集合|
        某些攻击可能增加与特征不相似的连接，使重合率下降；但方向和
        幅度依赖数据与攻击方式，不能将该指标直接解释为攻击强度。
        """
        knn_edge = self.get_knn_edge(x, edge_index)
        N = x.size(0)
        knn_key = knn_edge[0].long() * N + knn_edge[1].long()
        knn_key_set = set(knn_key.tolist())

        row, col = edge_index
        atk_key = (row.long() * N + col.long()).tolist()
        n_total = len(atk_key)
        if n_total == 0:
            return torch.tensor(0.0, device=x.device)
        n_overlap = sum(1 for k in atk_key if k in knn_key_set)
        overlap_ratio = n_overlap / n_total
        return torch.tensor(overlap_ratio, device=x.device)

    def _adaptive_knn_weight(self, overlap: torch.Tensor) -> torch.Tensor:
        """Map observed/kNN edge overlap to a view weight.

        The paper rule is retained as the default. The alternative is an
        explicitly experimental, non-saturating control for low-overlap
        datasets; it must be evaluated before use in reported results.
        """
        if self.fusion_rule == "paper":
            raw_weight = 1.0 - overlap
        else:
            raw_weight = 0.5 - overlap
        return raw_weight.clamp(min=0.01, max=0.5)

    @torch.no_grad()
    def fusion_diagnostics(self, x: torch.Tensor,
                           edge_index: torch.Tensor) -> dict:
        """Measure overlap and both fusion rules on the supplied graph."""
        if not self.use_knn_view:
            return {
                "fusion_rule": self.fusion_rule,
                "multiscale_inference": self.multiscale_inference,
                "ablation": self.ablation,
                "rho": None,
                "gamma_knn": 0.0,
                "gamma_paper": None,
                "gamma_linear_half_minus_rho": None,
                "paper_rule_saturated": None,
            }
        rho = float(self.estimate_attack_strength(x, edge_index).item())
        gamma_paper = min(0.5, max(0.01, 1.0 - rho))
        gamma_linear = min(0.5, max(0.01, 0.5 - rho))
        if self.fixed_knn_weight is not None:
            gamma_active = self.fixed_knn_weight
        else:
            gamma_active = (
                gamma_paper if self.fusion_rule == "paper" else gamma_linear
            )
        return {
            "fusion_rule": self.fusion_rule,
            "multiscale_inference": self.multiscale_inference,
            "ablation": self.ablation,
            "rho": rho,
            "gamma_knn": gamma_active,
            "gamma_paper": gamma_paper,
            "gamma_linear_half_minus_rho": gamma_linear,
            "paper_rule_saturated": 1.0 - rho >= 0.5,
        }

    @torch.no_grad()
    def _smooth_feat(self, x: torch.Tensor, edge_index: torch.Tensor,
                     edge_weight: torch.Tensor = None) -> torch.Tensor:
        """对特征做一次图传播平滑，作为低频分支的重建目标。"""
        return sparse_propagate(x, edge_index, x.size(0), edge_weight)

    # ──────────────────────────────────────────────────────────
    # 训练步骤
    # ──────────────────────────────────────────────────────────

    def train_step(self, data, optimizer):
        """
        单步预训练：特征掩码重建（解耦目标） + 跨视角（knn vs atk）对比学习。
        data : PyG Data 对象，含 x, edge_index（可能受攻击）
        """
        self.train()
        optimizer.zero_grad()

        x_orig     = data.x
        edge_index = data.edge_index           # 攻击视角（可能含污染边）
        knn_edge = (
            self.get_knn_edge(x_orig, edge_index)
            if self.use_knn_view else edge_index
        )

        # 边置信度软加权仅作用于观测图；kNN 视图使用未经加权的特征结构先验
        edge_w = (
            self.edge_confidence(x_orig, edge_index)
            if self.use_edge_confidence else None
        )

        # 1. 特征掩码
        x_masked, mask_nodes = self.encoding_mask_noise(x_orig, self._mask_rate)

        # 2. 三分支编码：在 kNN 视角下做主编码（用于重建与下游表示）
        z_l_knn = (
            self.low_enc(x_masked, knn_edge)
            if self.use_low_branch else None
        )
        z_h_knn = (
            self.high_enc(x_masked, knn_edge)
            if self.use_high_branch else None
        )
        z_f_knn = (
            self.frame_enc(x_masked, knn_edge)
            if self.use_frame_branch else None
        )

        # 3. 低/高频分支在攻击视角下再算一遍（用于跨视角对比，捕获攻击导致的偏移）
        z_l_atk = (
            self.low_enc(x_masked, edge_index, edge_weight=edge_w)
            if self.use_low_branch else None
        )
        z_h_atk = (
            self.high_enc(x_masked, edge_index, edge_weight=edge_w)
            if self.use_high_branch else None
        )
        # The original full model applies cross-view objectives only to the
        # low/high Chebyshev branches. For the multiscale-only and Three-LP
        # controls, the third branch is the available/controlled branch and is
        # therefore evaluated under the same self-supervised objectives.
        contrast_frame = self.use_frame_branch and (
            self.ablation in {"ms_only", "three_lp"}
            or self.multiscale_cross_view
        )
        z_f_atk = (
            self.frame_enc(x_masked, edge_index, edge_weight=edge_w)
            if self.use_frame_branch and contrast_frame else None
        )

        # 4. 重建目标解耦：
        #    低频 → kNN 图平滑特征
        #    高频 → 残差（默认）或平滑特征（显式目标对照）
        #    framelet → 原始特征
        x_smooth = self._smooth_feat(x_orig, knn_edge)
        x_residual = x_orig - x_smooth

        recon_terms = []
        if self.use_low_branch:
            recon_terms.append(
                freq_recon_loss(self.dec_low(z_l_knn), x_smooth, mask_nodes)
            )
        if self.use_high_branch:
            recon_terms.append(
                freq_recon_loss(
                    self.dec_high(z_h_knn),
                    (x_smooth if self.three_lp
                     or self.high_recon_target == "smooth" else x_residual),
                    mask_nodes,
                )
            )
        if self.use_frame_branch:
            recon_terms.append(
                freq_recon_loss(
                    self.dec_frame(z_f_knn),
                    x_smooth if self.three_lp else x_orig,
                    mask_nodes,
                )
            )
        loss_recon = torch.stack(recon_terms).mean()

        # 5. 跨视角 InfoNCE：正对 = 同节点在 knn视角 / atk视角 下的表示
        #    语义清晰：迫使编码器对攻击引入的结构噪声保持不变性
        nce_terms = []
        if self.use_low_branch:
            nce_terms.append(
                freq_infonce_loss(z_l_knn, z_l_atk, self.temperature)
            )
        if self.use_high_branch:
            nce_terms.append(
                freq_infonce_loss(z_h_knn, z_h_atk, self.temperature)
            )
        if contrast_frame:
            nce_terms.append(
                freq_infonce_loss(z_f_knn, z_f_atk, self.temperature)
            )
        loss_nce = torch.stack(nce_terms).mean()

        # 6. BCE 伪标签对齐：随机负对并尝试排除 kNN 邻居
        hard_neg_idx = self._sample_hard_negatives(x_orig, knn_edge)
        bce_terms = []
        if self.use_low_branch:
            bce_terms.append(
                freq_bce_loss(
                    z_l_knn, z_l_atk, self.bce_clf, hard_neg_idx
                )
            )
        if self.use_high_branch:
            bce_terms.append(
                freq_bce_loss(
                    z_h_knn, z_h_atk, self.bce_clf, hard_neg_idx
                )
            )
        if contrast_frame:
            bce_terms.append(
                freq_bce_loss(
                    z_f_knn, z_f_atk, self.bce_clf, hard_neg_idx
                )
            )
        loss_bce = torch.stack(bce_terms).mean()

        # 7. 总损失
        loss = (loss_recon
                + self.lambda_c * loss_nce
                + self.lambda_b * loss_bce
                )

        loss.backward()
        optimizer.step()

        return {
            "loss":   loss.item(),
            "recon":  loss_recon.item(),
            "nce":    loss_nce.item(),
            "bce":    loss_bce.item(),
        }

    @torch.no_grad()
    def _sample_hard_negatives(self, x: torch.Tensor,
                               knn_edge: torch.Tensor) -> torch.Tensor:
        """
        为每个节点随机采样一个负对。默认保留既有的一次冲突重抽逻辑，
        以便复现旧结果；它不能保证排除自身或 kNN 邻居。显式启用
        strict_negatives 后，从所有非自身、非邻居节点中均匀采样，
        不按特征相似度挑选难例。
        """
        N = x.size(0)
        device = x.device

        # 构建每个节点的 kNN 邻居集合（用于排除假负例）
        row, col = knn_edge
        neighbor_sets = [set() for _ in range(N)]
        row_list = row.tolist()
        col_list = col.tolist()
        for r, c in zip(row_list, col_list):
            neighbor_sets[r].add(c)

        if self.strict_negatives:
            # Treat either direction as adjacency, even if the caller passes
            # a directed edge list. A node with no valid negative is an error.
            for r, c in zip(row_list, col_list):
                neighbor_sets[c].add(r)
            draws = torch.rand(N, device=device).tolist()
            strict_idx = []
            for i, draw in enumerate(draws):
                forbidden = sorted(neighbor_sets[i] | {i})
                available = N - len(forbidden)
                if available <= 0:
                    raise ValueError(
                        f"Node {i} has no non-neighbor negative candidate"
                    )
                # Map a uniform rank in the allowed set to its node index.
                candidate = min(int(draw * available), available - 1)
                for excluded in forbidden:
                    if excluded > candidate:
                        break
                    candidate += 1
                strict_idx.append(candidate)
            return torch.tensor(strict_idx, dtype=torch.long, device=device)

        perm = torch.randperm(N, device=device)
        hard_neg_idx = perm.clone()

        # 对于打乱后仍落在自身 kNN 邻居集合内的位置，重新打乱一次修正
        # （概率很低，简单的二次修正足够，避免引入过多额外计算）
        conflict = torch.zeros(N, dtype=torch.bool, device=device)
        perm_list = perm.tolist()
        for i in range(N):
            if perm_list[i] in neighbor_sets[i] or perm_list[i] == i:
                conflict[i] = True

        if conflict.any():
            n_conflict = int(conflict.sum().item())
            fix_perm = torch.randperm(N, device=device)[:n_conflict]
            hard_neg_idx[conflict] = fix_perm

        return hard_neg_idx

    # ──────────────────────────────────────────────────────────
    # 推理：获取融合嵌入
    # ──────────────────────────────────────────────────────────

    @torch.no_grad()
    def get_embedding(self, x: torch.Tensor, edge_index,
                      mode: str = "concat", knn_weight: float = None,
                      verbose: bool = True) -> torch.Tensor:
        """
        推理时融合 kNN 视角与攻击视角的表示。

        默认使用论文中的 clip(1-rho, 0.01, 0.5)，其中 rho 是观测边与
        特征 kNN 边的重合率。实测某些数据集的 clean 与 attacked rho
        均小于 0.5，此时两者的 kNN 权重都达到 0.5 上限，门控不再
        区分攻击强度。实验性 linear_half_minus_rho 规则仅供受控消融，
        不属于默认论文方法。

        默认也融合多尺度分支的两视图输出。实验性 knn_only 规则仅用
        训练期受到重建监督的 kNN 输出，用于检验该分支的训练/推理差异。

        knn_weight : 若手动指定（0~1），跳过自适应估计，直接使用该权重
                    （便于做受控实验，比较固定权重 vs 自适应权重）。
        verbose    : 若为 True，打印 overlap_ratio / w_knn 诊断信息，
                    用于调试；批量实验或正式评估时建议关闭，避免日志噪声。
        """
        self.eval()
        knn_edge = (
            self.get_knn_edge(x, edge_index)
            if self.use_knn_view else edge_index
        )
        edge_w = (
            self.edge_confidence(x, edge_index)
            if self.use_edge_confidence else None
        )

        z_l_knn = self.low_enc(x, knn_edge) if self.use_low_branch else None
        z_h_knn = self.high_enc(x, knn_edge) if self.use_high_branch else None
        z_f_knn = self.frame_enc(x, knn_edge) if self.use_frame_branch else None

        z_l_atk = (
            self.low_enc(x, edge_index, edge_weight=edge_w)
            if self.use_low_branch else None
        )
        z_h_atk = (
            self.high_enc(x, edge_index, edge_weight=edge_w)
            if self.use_high_branch else None
        )
        z_f_atk = (
            self.frame_enc(x, edge_index, edge_weight=edge_w)
            if self.use_frame_branch and self.multiscale_inference == "fused"
            else None
        )

        if not self.use_knn_view:
            w_knn = torch.tensor(0.0, device=x.device)
            if verbose:
                print("[ablation wo_knn] using only the observed graph view")
        elif knn_weight is None and self.fixed_knn_weight is not None:
            w_knn = torch.tensor(self.fixed_knn_weight, device=x.device)
            if verbose:
                print(f"[ablation wo_af] fixed w_knn={w_knn.item():.4f}")
        elif knn_weight is None:
            overlap = self.estimate_attack_strength(x, edge_index)
            w_knn = self._adaptive_knn_weight(overlap)
            if verbose:
                label = (
                    "[auto]" if self.fusion_rule == "paper"
                    else f"[auto/{self.fusion_rule}]"
                )
                print(
                    f"{label} overlap_ratio="
                    f"{overlap.item():.4f}, w_knn={w_knn.item():.4f}"
                )
        else:
            w_knn = torch.tensor(knn_weight, device=x.device)
            if verbose:
                print(f"[manual] w_knn={w_knn.item():.4f}")

        w_atk = 1.0 - w_knn
        z_l = None
        embeddings = []
        if self.use_low_branch:
            z_l = w_knn * z_l_knn + w_atk * z_l_atk
            embeddings.append(z_l)
        z_h = None
        z_f = None
        if self.use_frame_branch:
            z_f = (
                z_f_knn if self.multiscale_inference == "knn_only"
                else w_knn * z_f_knn + w_atk * z_f_atk
            )
            embeddings.append(z_f)
        if self.use_high_branch:
            z_h = w_knn * z_h_knn + w_atk * z_h_atk
            embeddings.append(z_h)

        if mode == "concat":
            return torch.cat(embeddings, dim=-1)
        elif mode == "fuse":
            if z_l is None or z_h is None:
                return torch.cat(embeddings, dim=-1)
            z1 = self._fuse(z_l, z_h)
            return torch.cat([z1, z_f], dim=-1) if z_f is not None else z1
        else:
            if z_f is not None:
                return z_f
            return z_h if z_h is not None else z_l

    def forward(self, x: torch.Tensor, edge_index) -> torch.Tensor:
        """推理接口，返回 concat 融合嵌入，兼容 train_nodeclas。"""
        return self.get_embedding(x, edge_index, mode="concat")
