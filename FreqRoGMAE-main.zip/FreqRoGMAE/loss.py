import torch
import torch.nn.functional as F


def freq_infonce_loss(
    z_anchor,
    z_pos,
    temperature: float = 0.5,
    hard_neg_mask: torch.Tensor = None,
    chunk_size: int = 2048,
):
    """Cross-view InfoNCE with exact row chunking for large graphs."""
    z_anchor = F.normalize(z_anchor, p=2, dim=-1)
    z_pos = F.normalize(z_pos, p=2, dim=-1)
    num_nodes = z_anchor.size(0)

    # Row chunking computes the same full-negative InfoNCE objective while
    # reducing peak similarity memory from O(N^2) to O(chunk_size * N).
    chunk_size = num_nodes if num_nodes <= 4096 else min(chunk_size, num_nodes)
    total = z_anchor.new_zeros(())
    z_pos_t = z_pos.t()
    for start in range(0, num_nodes, chunk_size):
        end = min(start + chunk_size, num_nodes)
        similarity = torch.mm(z_anchor[start:end], z_pos_t) / temperature

        if hard_neg_mask is not None:
            local_mask = hard_neg_mask[start:end].bool().clone()
            row = torch.arange(end - start, device=similarity.device)
            col = torch.arange(start, end, device=similarity.device)
            local_mask[row, col] = True
            similarity = similarity.masked_fill(~local_mask, float("-1e4"))

        labels = torch.arange(start, end, device=similarity.device)
        total = total + F.cross_entropy(
            similarity, labels, reduction="sum"
        )
    return total / num_nodes


def freq_bce_loss(z_freq, z_anchor, clf, hard_neg_idx: torch.Tensor = None):
    """Binary cross-view discrimination with one negative per node."""
    num_nodes = z_freq.size(0)
    device = z_freq.device

    pos_input = torch.cat([z_freq, z_anchor], dim=-1)
    pos_logit = clf(pos_input).squeeze(-1)
    pos_label = torch.ones(num_nodes, device=device)

    if hard_neg_idx is not None:
        neg_input = torch.cat([z_freq, z_anchor[hard_neg_idx]], dim=-1)
    else:
        permutation = torch.randperm(num_nodes, device=device)
        neg_input = torch.cat([z_freq, z_anchor[permutation]], dim=-1)
    neg_logit = clf(neg_input).squeeze(-1)
    neg_label = torch.zeros(num_nodes, device=device)

    logits = torch.cat([pos_logit, neg_logit], dim=0)
    labels = torch.cat([pos_label, neg_label], dim=0)
    return F.binary_cross_entropy_with_logits(logits, labels)


def freq_recon_loss(recon, target, mask_nodes=None):
    """Scaled-cosine feature reconstruction loss."""
    if mask_nodes is not None:
        recon = recon[mask_nodes]
        target = target[mask_nodes]
    recon = F.normalize(recon, p=2, dim=-1)
    target = F.normalize(target, p=2, dim=-1)
    return (1 - (recon * target).sum(dim=-1)).mean()
