import sys
import os
import torch
import random
import numpy as np
from texttable import Texttable
import torch_geometric.transforms as T
from torch_geometric.datasets import Amazon, Coauthor, Planetoid, Reddit
from torch_geometric.data import Data
from torch_geometric.utils import index_to_mask
from deeprobust.graph.data import Dataset, PrePtbDataset, Dpr2Pyg, Pyg2Dpr
from torch_geometric.utils import (
    to_undirected,
    dense_to_sparse,
    to_dense_adj,
    to_scipy_sparse_matrix,
    from_scipy_sparse_matrix,
)
import json

def set_seed(seed: int):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed) # if you are using multi-GPU.
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.enabled = False

def get_dataset(root: str, name: str, transform=None) -> Data:
    if name in {'arxiv', 'products', 'mag'}:
        from ogb.nodeproppred import PygNodePropPredDataset
        print('loading ogb dataset...')
        dataset = PygNodePropPredDataset(root=root, name=f'ogbn-{name}')
        if name in ['mag']:
            rel_data = dataset[0]
            # We are only interested in paper <-> paper relations.
            data = Data(
                    x=rel_data.x_dict['paper'],
                    edge_index=rel_data.edge_index_dict[('paper', 'cites', 'paper')],
                    y=rel_data.y_dict['paper'])
            data = transform(data)
            split_idx = dataset.get_idx_split()
            data.train_mask = index_to_mask(split_idx['train']['paper'], data.num_nodes)
            data.val_mask = index_to_mask(split_idx['valid']['paper'], data.num_nodes)
            data.test_mask = index_to_mask(split_idx['test']['paper'], data.num_nodes)
        else:
            data = transform(dataset[0])
            split_idx = dataset.get_idx_split()
            data.train_mask = index_to_mask(split_idx['train'], data.num_nodes)
            data.val_mask = index_to_mask(split_idx['valid'], data.num_nodes)
            data.test_mask = index_to_mask(split_idx['test'], data.num_nodes)

    elif name in {'Cora', 'Citeseer', 'Pubmed'}:
        dataset = Planetoid(root, name)
        data = transform(dataset[0])

    elif name == 'Reddit':
        dataset = Reddit(osp.join(root, name))
        data = transform(dataset[0])
    elif name in {'Photo', 'Computers'}:
        dataset = Amazon(root, name)
        data = transform(dataset[0])
        data = T.RandomNodeSplit(num_val=0.1, num_test=0.8)(data)
    elif name in {'CS', 'Physics'}:
        dataset = Coauthor(root, name)
        data = transform(dataset[0])
        data = T.RandomNodeSplit(num_val=0.1, num_test=0.8)(data)
    else:
        raise ValueError(name)
    return data


def get_dataset_prognn(root: str, args, transform=None) -> Data:
    name = args.dataset
    if name in {'arxiv', 'products', 'mag'}:
        from ogb.nodeproppred import PygNodePropPredDataset
        print('loading ogb dataset...')
        dataset = PygNodePropPredDataset(root=root, name=f'ogbn-{name}')
        if name in ['mag']:
            rel_data = dataset[0]
            # We are only interested in paper <-> paper relations.
            data = Data(
                x=rel_data.x_dict['paper'],
                edge_index=rel_data.edge_index_dict[('paper', 'cites', 'paper')],
                y=rel_data.y_dict['paper'])
            data = transform(data)
            split_idx = dataset.get_idx_split()
            data.train_mask = index_to_mask(split_idx['train']['paper'], data.num_nodes)
            data.val_mask = index_to_mask(split_idx['valid']['paper'], data.num_nodes)
            data.test_mask = index_to_mask(split_idx['test']['paper'], data.num_nodes)
        else:
            data = transform(dataset[0])
            split_idx = dataset.get_idx_split()
            data.train_mask = index_to_mask(split_idx['train'], data.num_nodes)
            data.val_mask = index_to_mask(split_idx['valid'], data.num_nodes)
            data.test_mask = index_to_mask(split_idx['test'], data.num_nodes)

    elif name in {'Cora', 'Citeseer', 'Pubmed', 'cora', 'citeseer', 'pubmed'}:
        pyg_data = Dataset(root='./data/prognn/', name=name.lower(), setting='prognn')
        data = Dpr2Pyg(pyg_data)[0]

        # 结构攻击处理
        if args.attack in ['metattack', 'metafeattack']:
            perturbed_data = PrePtbDataset(root='./data/prognn/',
                                           name=name.lower(),
                                           attack_method='meta',
                                           ptb_rate=args.ptb)
            perturbed_adj = perturbed_data.adj
            edge_index = dense_to_sparse(torch.from_numpy(perturbed_adj.toarray()))[0].long()
            edge_index = to_undirected(edge_index)
            data.edge_index = edge_index

        elif args.attack in ['netclean']:
            dataset = Dataset(root='./data/prognn/', name=name)
            pyg_data = Dpr2Pyg(dataset)
            data = pyg_data[0]

            # 处理test_mask
            if args.ptb > 5:
                with open('./data/nettack/{}_nettacked_nodes.json'.format(name), 'r') as f:
                    noo = json.load(f)
                attacked_nodes = noo["attacked_test_nodes"]
                test_mask = torch.zeros(data.num_nodes, dtype=torch.bool)
                test_mask[attacked_nodes] = True
                data.test_mask = test_mask

        elif args.attack in ['nettack', 'netfeattack']:
            # perturbed_data = torch.load(f'./data/nettack/{name.lower()}_nettack_adj_{args.ptb}.npz')
            perturbed_data = PrePtbDataset(root='./data/nettack/',
                                           name=name.lower(),
                                           attack_method='nettack',
                                           ptb_rate=args.ptb)
            perturbed_adj = perturbed_data.adj
            edge_index = dense_to_sparse(torch.from_numpy(perturbed_adj.toarray()))[0].long()
            edge_index = to_undirected(edge_index)
            data.edge_index = edge_index
            idx_test = perturbed_data.target_nodes
            mask = torch.zeros(data.x.size()[0], dtype=torch.bool)
            mask[idx_test] = True
            data.test_mask = mask

        # 特征攻击处理
        if args.attack in ['feattack', 'metafeattack', 'netfeattack']:
            # 随机选择50%的节点进行特征攻击
            num_nodes = data.x.size(0)
            num_attacked_nodes = num_nodes // 2
            feat_attacked_nodes = np.random.choice(num_nodes, num_attacked_nodes, replace=False)
            feat_attacked_mask = np.in1d(np.arange(num_nodes), feat_attacked_nodes)

            # 生成高斯噪声并添加到被攻击节点的特征中
            perturb = torch.randn_like(data.x)
            data.x[feat_attacked_mask] = data.x[feat_attacked_mask] + perturb[feat_attacked_mask] * 0.5

        elif args.attack == 'dice':
            ptb = args.ptb
            # 保持变量命名习惯，原始数据集用 dataset
            dataset = Dataset(root='./data/prognn/', name=name.lower(), setting='prognn')
            adj, labl = dataset.adj, dataset.labels

            from deeprobust.graph.global_attack import DICE
            attacker = DICE()
            n_perturbations = int(ptb * (adj.sum() // 2))
            attacker.attack(adj, labl, n_perturbations=n_perturbations)

            # 提取攻击后的邻接矩阵并转为 edge_index
            adj = attacker.modified_adj
            edge_index = dense_to_sparse(torch.from_numpy(adj.toarray()))[0].long()
            edge_index = to_undirected(edge_index)

            # 转换为 PyG 的 Data 对象，并替换边信息
            pyg_data = Dpr2Pyg(dataset)
            data = pyg_data[0]
            data.edge_index = edge_index

        elif args.attack == "random":
            ptb = args.ptb
            dataset = Dataset(root='./data/prognn/', name=name.lower(), setting='prognn')
            print("random attack with rate %.2f" % ptb)

            from deeprobust.graph.global_attack import Random
            adj = dataset.adj
            # import random
            # random.seed(args.seed)
            # np.random.seed(args.seed)

            attacker = Random()
            n_perturbations = int(ptb * (adj.sum() // 2))
            attacker.attack(adj, n_perturbations, type='add')

            # 提取攻击后的邻接矩阵并转为 edge_index
            adj = attacker.modified_adj
            edge_index = dense_to_sparse(torch.from_numpy(adj.toarray()))[0].long()
            edge_index = to_undirected(edge_index)

            # 转换为 PyG 的 Data 对象，并替换边信息
            pyg_data = Dpr2Pyg(dataset)
            data = pyg_data[0]
            data.edge_index = edge_index

        # if args.attack == 'dice':
        #     ptb = args.ptb
        #     data = Dataset(root='./data/dataset', name=name, setting='prognn')
        #     adj, labl = data.adj, data.labels
        #     from deeprobust.graph.global_attack import DICE
        #     attacker = DICE()
        #     n_perturbations = int(ptb * (adj.sum() // 2))
        #     attacker.attack(adj, labl, n_perturbations=n_perturbations)
        #     adj = attacker.modified_adj
        #     edge_index = dense_to_sparse(torch.from_numpy(adj.toarray()))[0].long()
        #     edge_index = to_undirected(edge_index)
        #     pyg_data = Dpr2Pyg(data)
        #     graph = dgl.graph((edge_index[0], edge_index[1]), num_nodes=pyg_data[0].x.size(0))
        #     graph.ndata["feat"] = pyg_data[0].x
        #     graph.ndata["label"] = pyg_data[0].y
        #     graph.ndata["train_mask"] = pyg_data[0].train_mask
        #     graph.ndata["val_mask"] = pyg_data[0].val_mask
        #     graph.ndata["test_mask"] = pyg_data[0].test_mask
        #     graph = graph.remove_self_loop()
        #     graph = graph.add_self_loop()
        #
        # if args.attack == "random":
        #     ptb = args.ptb
        #     data = Dataset(root='./data/dataset', name=name, setting='prognn')
        #     print("random attack with rate %.2f" % ptb)
        #     from deeprobust.graph.global_attack import Random
        #     adj = data.adj
        #     # to fix the seed of generated random attack, you need to fix both np.random and random
        #     # you can uncomment the following code
        #     # import random
        #     # random.seed(args.seed)
        #     # np.random.seed(args.seed)
        #     attacker = Random()
        #     n_perturbations = int(ptb * (adj.sum() // 2))
        #     attacker.attack(adj, n_perturbations, type='add')
        #     adj = attacker.modified_adj
        #     edge_index = dense_to_sparse(torch.from_numpy(adj.toarray()))[0].long()
        #     edge_index = to_undirected(edge_index)
        #     pyg_data = Dpr2Pyg(data)
        #     graph = dgl.graph((edge_index[0], edge_index[1]), num_nodes=pyg_data[0].x.size(0))
        #     graph.ndata["feat"] = pyg_data[0].x
        #     graph.ndata["label"] = pyg_data[0].y
        #     graph.ndata["train_mask"] = pyg_data[0].train_mask
        #     graph.ndata["val_mask"] = pyg_data[0].val_mask
        #     graph.ndata["test_mask"] = pyg_data[0].test_mask

    elif name == 'Reddit':
        dataset = Reddit(os.join(root, name))
        data = transform(dataset[0])

        # 特征攻击处理
        if args.attack in ['feattack', 'metafeattack', 'netfeattack']:
            num_nodes = data.x.size(0)
            num_attacked_nodes = num_nodes // 2
            feat_attacked_nodes = np.random.choice(num_nodes, num_attacked_nodes, replace=False)
            feat_attacked_mask = np.in1d(np.arange(num_nodes), feat_attacked_nodes)

            perturb = torch.randn_like(data.x)
            data.x[feat_attacked_mask] = data.x[feat_attacked_mask] + perturb[feat_attacked_mask] * 0.5

    elif name in {'Photo', 'Computers'}:
        dataset = Amazon(root, name)
        data = transform(dataset[0])

        # 结构攻击处理
        if args.attack in ['metattack', 'metafeattack']:
            ptb = args.ptb
            if name == "Photo":
                edge = torch.load(
                    f'./data/prognn/photo_meta_adj_{ptb}.pt',
                    map_location=data.x.device,
                )
            else:
                edge = torch.load(
                    f'./data/prognn/computers_meta_adj_{ptb}.pt',
                    map_location=data.x.device,
                )
            data.edge_index = edge.to(data.x.device)

        elif args.attack == 'dice':
            ptb = args.ptb
            print(f"{name} DICE attack with rate {ptb:.2f}")

            from deeprobust.graph.global_attack import DICE

            edge_device = data.edge_index.device
            adj = to_scipy_sparse_matrix(
                data.edge_index.detach().cpu(),
                num_nodes=data.num_nodes,
            ).tocsr()
            labels = data.y.detach().cpu().numpy()
            n_perturbations = int(ptb * (adj.sum() // 2))

            attacker = DICE()
            attacker.attack(
                adj,
                labels,
                n_perturbations=n_perturbations,
            )
            modified_edge_index, _ = from_scipy_sparse_matrix(
                attacker.modified_adj
            )
            data.edge_index = to_undirected(
                modified_edge_index,
                num_nodes=data.num_nodes,
            ).to(edge_device)

        # 特征攻击处理
        if args.attack in ['feattack', 'metafeattack', 'netfeattack']:
            num_nodes = data.x.size(0)
            num_attacked_nodes = num_nodes // 2
            feat_attacked_nodes = np.random.choice(num_nodes, num_attacked_nodes, replace=False)
            feat_attacked_mask = np.in1d(np.arange(num_nodes), feat_attacked_nodes)

            perturb = torch.randn_like(data.x)
            data.x[feat_attacked_mask] = data.x[feat_attacked_mask] + perturb[feat_attacked_mask] * 0.5

        data = T.RandomNodeSplit(num_val=0.1, num_test=0.8)(data)

    elif name in {'CS', 'Physics'}:
        dataset = Coauthor(root, name)
        data = transform(dataset[0])

        # 特征攻击处理
        if args.attack in ['feattack', 'metafeattack', 'netfeattack']:
            num_nodes = data.x.size(0)
            num_attacked_nodes = num_nodes // 2
            feat_attacked_nodes = np.random.choice(num_nodes, num_attacked_nodes, replace=False)
            feat_attacked_mask = np.in1d(np.arange(num_nodes), feat_attacked_nodes)

            perturb = torch.randn_like(data.x)
            data.x[feat_attacked_mask] = data.x[feat_attacked_mask] + perturb[feat_attacked_mask] * 0.5

        data = T.RandomNodeSplit(num_val=0.1, num_test=0.8)(data)
    else:
        raise ValueError(name)

    # # 设置攻击类型标记
    # if args.attack_type == 'clean':
    #     data.attack_type = 'clean'
    # elif args.attack_type == 'poison':
    #     data.attack_type = 'poison'
    # elif args.attack_type == 'evasive':
    #     data.attack_type = 'evasive'

    return data
    
def tab_printer(args):
    """Function to print the logs in a nice tabular format.

    Note
    ----
    Package `Texttable` is required.
    Run `pip install Texttable` if was not installed.

    Parameters
    ----------
    args: Parameters used for the model.
    """
    args = vars(args)
    keys = sorted(args.keys())
    t = Texttable()
    t.add_rows([["Parameter", "Value"]] + [[k, str(args[k])] for k in keys if not k.startswith('__')])
    return t.draw()

import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt

def loss_plt(loss_values):
    # 创建 x 轴数据，表示 epoch 的数量
    epochs = range(1, len(loss_values) + 1)
    # 绘制损失函数曲线
    plt.plot(epochs, loss_values, 'b-', label='Training Loss')

    # 添加标题和标签
    plt.title('Training Loss Curve')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    # 显示图例
    plt.legend()
    # 显示图形
    plt.show()
