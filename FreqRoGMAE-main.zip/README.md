# FreqRoGMAE

This repository implements frequency-aware robust graph masked autoencoding for node classification under graph perturbations. `train_freq_robust.py` is the main entry point. The code also exposes optional ablation flags; the default `--ablation full` is the proposed model.

## Environment

Use Python 3.9 to reproduce the tested environment, then install a mutually compatible PyTorch, PyTorch Geometric, `torch-scatter`, `torch-sparse`, and `torch-cluster` build for your CPU/CUDA environment. The development environment used PyTorch 2.8.0, PyG 2.6.1, `torch-sparse` 0.6.18, `torch-scatter` 2.1.2, and `torch-cluster` 1.6.3. Install the remaining Python dependencies with:

```bash
pip install -r requirements.txt
```

The repository's older `requirements.txt` records an early experimental environment and should not be mixed with the versions above.

## Data

- Cora, Citeseer, and Pubmed use DeepRobust's ProGNN dataset format under `data/prognn/`. The loader requests the clean graph from `Dataset` and precomputed Metattack graphs from `PrePtbDataset`.
- Nettack experiments use precomputed attack files under `data/nettack/` via `PrePtbDataset`.
- Photo and Computers clean graphs are loaded through PyG `Amazon`, which can download/cache the public datasets under `data/`.
- Photo/Computers Metattack experiments additionally require precomputed `data/prognn/photo_meta_adj_<ptb>.pt` or `computers_meta_adj_<ptb>.pt` files.

Attack files, cached kNN graphs, checkpoints, and experimental results are excluded from the code submission. Obtain or generate the attack files before running the associated commands. The code does not generate Metattack or Nettack perturbations itself.

## Run

Run from the repository root. For a clean graph:

```bash
python train_freq_robust.py --dataset Photo --attack clean --device 0 --seed 2026
```

For a precomputed structural attack:

```bash
python train_freq_robust.py --dataset Cora --attack metattack --ptb 0.25 --device 0 --seed 2026
```

Use `--device -1` for CPU. The best pretraining checkpoint is selected by reconstruction loss and written to `model_save/`. The printed `Node Classification (N runs)` aggregates N linear classifier initializations on **one pretrained encoder**. For independent end-to-end trials, repeat the command with different `--seed` values and distinct output directories, then aggregate those trials separately.

The model caches a feature-keyed kNN graph under `data/knn_cache/`. The optional `--strict_negatives` flag guarantees non-self, non-neighbor BCE negative pairs; it changes pretraining relative to the original default. `--help` lists all ablation and evaluation controls.

## Checks

```bash
python -m unittest discover -s tests -p 'test_*.py'
python tests/test_sparse_matmul_equivalence.py
```

The tests exercise kNN cache identity, negative sampling, reconstruction-target controls, and sparse operator equivalence. They do not reproduce full paper tables. Use independent seeds and the exact dataset splits and attack files used for each reported result.

## Submission contents

The standalone code archive contains the main training script, `FreqRoGMAE/` model and loss code, three small regression checks, the sequential clean-grid script, this README, and `requirements.txt`. It omits local datasets, model weights, logs, generated figures, manuscript files, and exploratory scripts.
