"""Check the optional large-graph sparse path against the original operators."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import torch
from torch_geometric.nn import ChebConv

from FreqRoGMAE.model import FreqRobustGMAE, cheb_conv_sparse, sparse_propagate


def main() -> None:
    torch.manual_seed(2026)
    edge_index = torch.tensor([
        [0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 0, 5],
        [1, 0, 2, 1, 3, 2, 4, 3, 5, 4, 5, 0],
    ])
    edge_weight = torch.rand(edge_index.size(1), dtype=torch.double) * 0.7 + 0.3
    conv = ChebConv(7, 5, K=5).double()
    x = torch.randn(6, 7, dtype=torch.double, requires_grad=True)
    weights = list(conv.parameters())

    original = conv(x, edge_index, edge_weight=edge_weight)
    original_grads = torch.autograd.grad(original.square().sum(), [x, *weights])
    sparse = cheb_conv_sparse(conv, x, edge_index, edge_weight=edge_weight)
    sparse_grads = torch.autograd.grad(sparse.square().sum(), [x, *weights])
    torch.testing.assert_close(sparse, original, rtol=1e-11, atol=1e-11)
    for actual, expected in zip(sparse_grads, original_grads):
        torch.testing.assert_close(actual, expected, rtol=1e-10, atol=1e-10)

    import os
    os.environ.pop("FREQROGMAE_SPARSE_MATMUL", None)
    baseline = sparse_propagate(x, edge_index, 6, edge_weight)
    baseline_grad = torch.autograd.grad(baseline.square().sum(), x)
    os.environ["FREQROGMAE_SPARSE_MATMUL"] = "1"
    optimized = sparse_propagate(x, edge_index, 6, edge_weight)
    optimized_grad = torch.autograd.grad(optimized.square().sum(), x)
    torch.testing.assert_close(optimized, baseline, rtol=1e-11, atol=1e-11)
    torch.testing.assert_close(optimized_grad[0], baseline_grad[0], rtol=1e-10, atol=1e-10)
    os.environ.pop("FREQROGMAE_SPARSE_MATMUL", None)

    model = FreqRobustGMAE(in_channels=7, hidden_channels=8,
                          out_channels=8, K=3, J=2)
    features = torch.randn(40, 7)
    many_edges = torch.randint(0, 40, (2, 20000))
    reference_weight = model.edge_confidence(features, many_edges)
    os.environ["FREQROGMAE_SPARSE_MATMUL"] = "1"
    chunked_weight = model.edge_confidence(features, many_edges)
    torch.testing.assert_close(chunked_weight, reference_weight,
                               rtol=1e-6, atol=1e-6)
    os.environ.pop("FREQROGMAE_SPARSE_MATMUL", None)
    print("Sparse propagation and chunked confidence match the original path.")


if __name__ == "__main__":
    main()
