"""Regression checks for feature-keyed kNN caches and strict negative sampling."""

import os
from pathlib import Path
import tempfile
import unittest

import torch
from torch_geometric.data import Data

from FreqRoGMAE.model import FreqRobustGMAE


def make_model(in_channels, *, strict_negatives=False):
    return FreqRobustGMAE(
        in_channels=in_channels,
        hidden_channels=4,
        out_channels=4,
        K=2,
        J=1,
        knn_k=2,
        strict_negatives=strict_negatives,
    )


class FeatureCacheTest(unittest.TestCase):
    def test_same_shape_different_features_and_in_place_update(self):
        n, d = 12, 6
        x_a = torch.randn(n, d, generator=torch.Generator().manual_seed(53))
        x_b = x_a.flip(0).clone()
        nodes = torch.arange(n)
        edge_index = torch.stack([
            nodes.repeat(2),
            torch.cat(((nodes + 1) % n, (nodes - 1) % n)),
        ])
        graph_a = Data(x=x_a, edge_index=edge_index)
        graph_b = Data(x=x_b, edge_index=edge_index)

        with tempfile.TemporaryDirectory() as temp_dir:
            original_dir = Path.cwd()
            try:
                os.chdir(temp_dir)
                cache_dir = Path("data/knn_cache")
                cache_dir.mkdir(parents=True)
                legacy_path = cache_dir / f"knn_n{n}_d{d}_k2.pt"
                torch.save(torch.empty((2, 0), dtype=torch.long), legacy_path)

                model = make_model(d)
                edges_a = model.get_knn_edge(graph_a.x, graph_a.edge_index)
                self.assertGreater(edges_a.size(1), 0)  # legacy file ignored
                self.assertIs(
                    edges_a, model.get_knn_edge(graph_a.x, graph_a.edge_index)
                )  # same tensor/version: memory hit

                edges_b = model.get_knn_edge(graph_b.x, graph_b.edge_index)
                self.assertFalse(torch.equal(edges_a, edges_b))
                hashed_paths = list(cache_dir.glob("knn_*_x*.pt"))
                self.assertEqual(len(hashed_paths), 2)

                fresh_model = make_model(d)
                disk_edges_a = fresh_model.get_knn_edge(
                    graph_a.x, graph_a.edge_index
                )
                self.assertTrue(torch.equal(edges_a, disk_edges_a))

                graph_a.x.copy_(graph_b.x)  # same tensor, incremented version
                updated_edges = fresh_model.get_knn_edge(
                    graph_a.x, graph_a.edge_index
                )
                self.assertTrue(torch.equal(edges_b, updated_edges))
                self.assertEqual(len(list(cache_dir.glob("knn_*_x*.pt"))), 2)
            finally:
                os.chdir(original_dir)

    def test_strict_negatives_exclude_self_and_either_direction(self):
        n = 10
        x = torch.randn(n, 3, generator=torch.Generator().manual_seed(19))
        # A directed cycle tests both incoming and outgoing exclusions.
        edge_index = torch.stack([torch.arange(n), (torch.arange(n) + 1) % n])
        graph = Data(x=x, edge_index=edge_index)
        model = make_model(3, strict_negatives=True)

        for seed in range(20):
            torch.manual_seed(seed)
            negatives = model._sample_hard_negatives(graph.x, graph.edge_index)
            self.assertEqual(negatives.shape, (n,))
            for node, negative in enumerate(negatives.tolist()):
                self.assertNotEqual(node, negative)
                self.assertNotEqual((node + 1) % n, negative)
                self.assertNotEqual((node - 1) % n, negative)

    def test_strict_negatives_reject_graph_without_candidate(self):
        n = 4
        graph = Data(
            x=torch.randn(n, 3),
            edge_index=torch.tensor([
                [u for u in range(n) for v in range(n) if u != v],
                [v for u in range(n) for v in range(n) if u != v],
            ]),
        )
        model = make_model(3, strict_negatives=True)
        with self.assertRaisesRegex(ValueError, "no non-neighbor negative"):
            model._sample_hard_negatives(graph.x, graph.edge_index)


if __name__ == "__main__":
    unittest.main()
