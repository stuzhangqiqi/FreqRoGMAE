"""Check the fixed-architecture high-branch reconstruction-target control."""

import os
from pathlib import Path
import tempfile
import unittest

import torch
from torch_geometric.data import Data

from FreqRoGMAE.model import FreqRobustGMAE


class HighTargetTest(unittest.TestCase):
    def setUp(self):
        n, d = 12, 6
        nodes = torch.arange(n)
        self.data = Data(
            x=torch.randn(n, d, generator=torch.Generator().manual_seed(81)),
            edge_index=torch.stack([
                nodes.repeat(2),
                torch.cat(((nodes + 1) % n, (nodes - 1) % n)),
            ]),
        )

    def make_model(self, *, ablation="full", target="residual"):
        return FreqRobustGMAE(
            in_channels=self.data.num_features,
            hidden_channels=4,
            out_channels=4,
            mask_rate=0.5,
            K=2,
            J=1,
            dropout=0,
            knn_k=2,
            ablation=ablation,
            high_recon_target=target,
        )

    def paired_steps(self, *, ablation):
        residual = self.make_model(ablation=ablation)
        smooth = self.make_model(ablation=ablation, target="smooth")
        smooth.load_state_dict(residual.state_dict())
        self.assertEqual(
            sum(p.numel() for p in residual.parameters()),
            sum(p.numel() for p in smooth.parameters()),
        )
        residual_opt = torch.optim.Adam(residual.parameters(), lr=0.001)
        smooth_opt = torch.optim.Adam(smooth.parameters(), lr=0.001)

        with tempfile.TemporaryDirectory() as temp_dir:
            original_dir = Path.cwd()
            try:
                os.chdir(temp_dir)
                torch.manual_seed(905)
                residual_loss = residual.train_step(self.data, residual_opt)
                torch.manual_seed(905)
                smooth_loss = smooth.train_step(self.data, smooth_opt)
            finally:
                os.chdir(original_dir)
        return residual_loss, smooth_loss

    def test_full_model_changes_only_reconstruction_target(self):
        residual, smooth = self.paired_steps(ablation="full")
        self.assertNotAlmostEqual(residual["recon"], smooth["recon"], places=6)
        self.assertAlmostEqual(residual["nce"], smooth["nce"], places=6)
        self.assertAlmostEqual(residual["bce"], smooth["bce"], places=6)

    def test_three_lp_remains_smooth_under_both_flag_values(self):
        residual, smooth = self.paired_steps(ablation="three_lp")
        for key in ("loss", "recon", "nce", "bce"):
            self.assertAlmostEqual(residual[key], smooth[key], places=6)


if __name__ == "__main__":
    unittest.main()
