
import argparse
import json
import os
import threading
import time
import numpy as np
import psutil
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch_geometric.transforms as T
from tqdm.auto import tqdm
from torch.optim import Adam
from torch.utils.data import DataLoader

# ── 从原始代码库导入
from FreqRoGMAE.model import FreqRobustGMAE
from FreqRoGMAE.utils import set_seed, tab_printer, get_dataset_prognn


class PeakRSSMonitor:
    """Sample this process's resident memory during one profiling run."""

    def __init__(self, interval=0.05):
        self.interval = interval
        self.process = psutil.Process(os.getpid())
        self.baseline = self.process.memory_info().rss
        self.peak = self.baseline
        self._stop_event = threading.Event()
        self._thread = threading.Thread(target=self._sample, daemon=True)

    def _sample(self):
        while not self._stop_event.is_set():
            try:
                self.peak = max(self.peak, self.process.memory_info().rss)
            except psutil.Error:
                break
            self._stop_event.wait(self.interval)

    def start(self):
        self._thread.start()

    def stop(self):
        self._stop_event.set()
        self._thread.join(timeout=1.0)
        try:
            self.peak = max(self.peak, self.process.memory_info().rss)
        except psutil.Error:
            pass


class LogReg(nn.Module):
    def __init__(self, ft_in, nb_classes):
        super().__init__()
        self.fc = nn.Linear(ft_in, nb_classes)
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight.data)
                if m.bias is not None:
                    m.bias.data.fill_(0.0)

    def forward(self, x):
        return self.fc(x)

def train_nodeclas(model, data, args, device="cpu", eval_data=None):
    """冻结编码器，训练线性分类头，报告 test accuracy。"""

    @torch.no_grad()
    def test(loader, eval_embedding, eval_labels):
        clf.eval()
        logits, labels = [], []
        for nodes in loader:
            logits.append(clf(eval_embedding[nodes]))
            labels.append(eval_labels[nodes])
        logits = torch.cat(logits, dim=0).cpu().argmax(1)
        labels = torch.cat(labels, dim=0).cpu()
        return (logits == labels).float().mean().item()

    batch_size = 4096 if args.dataset in {"arxiv", "products", "mag"} else 512

    train_loader = DataLoader(data.train_mask.nonzero().view(-1),
                              batch_size=batch_size, shuffle=True)
    val_loader   = DataLoader(data.val_mask.nonzero().view(-1),  batch_size=20000)
    if eval_data is None:
        eval_data = data
    test_loader = DataLoader(
        eval_data.test_mask.nonzero().view(-1), batch_size=20000
    )

    data = data.to(device)
    y   = data.y.squeeze()

    # 获取冻结嵌入（三分支 concat，维度 = 3 * out_channels）
    embedding = model.get_embedding(data.x, data.edge_index, mode="concat")
    if args.l2_normalize:
        embedding = F.normalize(embedding, p=2, dim=1)

    # In an evasion setting, the encoder and linear classifier are learned on
    # the clean graph, while only test-time message passing uses the attacked
    # topology.  Poisoning keeps eval_data identical to data.
    if eval_data is data:
        test_embedding = embedding
        test_y = y
    else:
        eval_data = eval_data.to(device)
        test_embedding = model.get_embedding(
            eval_data.x, eval_data.edge_index, mode="concat"
        )
        if args.l2_normalize:
            test_embedding = F.normalize(test_embedding, p=2, dim=1)
        test_y = eval_data.y.squeeze()

    n_cls = y.max().item() + 1
    loss_fn   = nn.CrossEntropyLoss()

    results = []
    for run in range(1, args.runs + 1):
        clf = nn.Linear(embedding.size(1), n_cls).to(device)
        nn.init.xavier_uniform_(clf.weight.data)
        nn.init.zeros_(clf.bias.data)
        optimizer = Adam(clf.parameters(), lr=0.1,
                         weight_decay=args.nodeclas_weight_decay)
        best_val, best_test = 0.0, 0.0

        for epoch in tqdm(range(1, 101), desc=f"NodeClas run {run}"):
            clf.train()
            for nodes in train_loader:
                optimizer.zero_grad()
                loss_fn(clf(embedding[nodes]), y[nodes]).backward()
                optimizer.step()

            if epoch % 10 == 0:
                val_acc = test(val_loader, embedding, y)
                test_acc = test(test_loader, test_embedding, test_y)
                if val_acc > best_val:
                    best_val  = val_acc
                    best_test = test_acc

        results.append(best_test)
        print(f"  Run {run}: test acc {best_test:.4f}")

    print(f"\nNode Classification ({args.runs} runs): "
          f"{np.mean(results):.4f} ± {np.std(results):.4f}")
    return results

def pretrain(model, data, args, device="cpu"):
    """FreqRobustGMAE 预训练（特征重建 + 频率对比）。"""
    print("\n=== FreqRobustGMAE Pretraining ===")
    optimizer = Adam(model.parameters(),
                     lr=args.lr, weight_decay=args.weight_decay)

    data = data.to(device)
    best_recon = float("inf")
    best_epoch = -1
    epoch_times = []

    for epoch in tqdm(range(1, args.epochs + 1), desc="Pretraining"):
        t0 = time.time()
        logs = model.train_step(data, optimizer)
        epoch_times.append(time.time() - t0)

        if epoch % args.eval_period == 0:
            print(f"  Epoch {epoch:04d} | "
                  f"loss={logs['loss']:.4f}  "
                  f"recon={logs['recon']:.4f}  "
                  f"nce={logs['nce']:.4f}  "
                  f"bce={logs['bce']:.4f}  "
                  )

        if logs["recon"] < best_recon:
            best_recon = logs["recon"]
            best_epoch = epoch
            torch.save(model.state_dict(), args.save_path)

    avg_t = sum(epoch_times) / len(epoch_times)
    print(f"[Profiling] avg {avg_t*1000:.1f} ms/epoch")
    print(f"Best checkpoint at epoch {best_epoch} (recon={best_recon:.4f})")

    # 恢复最优权重
    model.load_state_dict(torch.load(args.save_path))

def parse_args():
    p = argparse.ArgumentParser(
        description="FreqRobustGMAE: frequency-aware robust graph MAE")

    # 数据集 & 攻击
    p.add_argument("--dataset", default="Citeseer")
    p.add_argument("--attack",  default="nettack", choices=["clean", "metattack", "nettack", "random", "dice","feattack", "metafeattack", "netfeattack", "netclean"])
    p.add_argument("--ptb",     type=float, default=1.0)

    # 模型结构
    p.add_argument("--hidden_channels",  type=int,   default=256, help="每个频率分支的输出维度（最终 concat 为 3x）")
    p.add_argument("--K",                type=int,   default=7, help="Chebyshev 多项式阶数")
    p.add_argument("--J",                type=int,   default=5, help="多尺度扩散残差深度")
    p.add_argument("--dropout",          type=float, default=0.5)
    p.add_argument("--mask_rate",        type=float, default=0.7)
    p.add_argument(
        "--ablation",
        default="full",
        choices=[
            "full", "wo_knn", "wo_ec", "lp_only",
            "wo_high", "wo_ms", "wo_nce", "wo_bce", "wo_af",
            "high_only", "ms_only", "three_lp",
        ],
        help="Ablation variant; 'full' keeps the complete model.",
    )
    p.add_argument(
        "--fusion_rule",
        choices=["paper", "linear_half_minus_rho"],
        default="paper",
        help=("Inference fusion rule. The experimental alternative uses "
              "clip(0.5-rho, 0.01, 0.5); 'paper' preserves published runs."),
    )
    p.add_argument(
        "--multiscale_cross_view",
        action="store_true",
        help=("Experimental: include the observed-view multiscale branch "
              "in cross-view InfoNCE and BCE pre-training."),
    )
    p.add_argument(
        "--strict_negatives",
        action="store_true",
        help=("Experimental pre-training control: sample uniformly from "
              "non-self, non-kNN-neighbor nodes; old runs used one retry."),
    )
    p.add_argument(
        "--high_recon_target",
        choices=["residual", "smooth"],
        default="residual",
        help=("High-branch reconstruction target; smooth is an experimental "
              "fixed-architecture control. Three-LP remains smooth."),
    )
    p.add_argument(
        "--edge_weight_mode",
        choices=["confidence", "uniform_half"],
        default="confidence",
        help=("Observed-edge weighting. Experimental uniform_half holds all "
              "weights at 0.5; confidence preserves the existing method."),
    )
    p.add_argument(
        "--multiscale_inference",
        choices=["fused", "knn_only"],
        default="fused",
        help=("Experimental inference control: fuse both multiscale "
              "views or use only its pre-trained kNN view."),
    )
    p.add_argument(
        "--fusion_diagnostics",
        action="store_true",
        help="Print measured rho and candidate/active fusion weights as JSON.",
    )
    p.add_argument(
        "--eval_only_checkpoint",
        default=None,
        help=("Load the same pre-trained state for controlled inference "
              "fusion comparisons; skip pre-training."),
    )

    # 损失权重
    p.add_argument("--lambda_c",  type=float, default=0.5, help="InfoNCE 损失权重")
    p.add_argument("--lambda_b",  type=float, default=0.1, help="BCE 伪标签损失权重,0.5")
    # p.add_argument("--lambda_r",  type=float, default=0.1, help="频率鲁棒一致性损失权重")
    p.add_argument("--temperature", type=float, default=0.5)

    # 训练超参
    p.add_argument("--lr",           type=float, default=0.001, help="1e-3")
    p.add_argument("--weight_decay", type=float, default=5e-5)
    p.add_argument("--epochs",       type=int,   default=300)
    p.add_argument("--eval_period",  type=int,   default=10)
    p.add_argument("--runs",         type=int,   default=5)
    p.add_argument("--nodeclas_weight_decay", type=float, default=0.005)
    p.add_argument("--l2_normalize", action="store_true")
    p.add_argument("--seed",         type=int,   default=2026)
    p.add_argument("--device",       type=int,   default=0)
    p.add_argument(
        "--save_dir",
        default="model_save",
        help="Directory used for temporary best-checkpoint files.",
    )

    return p.parse_args()


# ════════════════════════════════════════════════
# 主函数
# ════════════════════════════════════════════════

def main():
    total_start_time = time.perf_counter()
    args = parse_args()
    if args.eval_only_checkpoint and args.multiscale_cross_view:
        raise ValueError(
            "--multiscale_cross_view changes pre-training; do not combine it "
            "with --eval_only_checkpoint from the default model."
        )
    if args.eval_only_checkpoint and args.strict_negatives:
        raise ValueError(
            "--strict_negatives changes pre-training; do not combine it "
            "with --eval_only_checkpoint from the default model."
        )
    if args.eval_only_checkpoint and args.high_recon_target != "residual":
        raise ValueError(
            "--high_recon_target smooth changes pre-training; do not combine "
            "it with --eval_only_checkpoint from the default model."
        )
    if args.eval_only_checkpoint and args.edge_weight_mode != "confidence":
        raise ValueError(
            "--edge_weight_mode uniform_half changes pre-training; do not "
            "combine it with --eval_only_checkpoint from the default model."
        )
    os.makedirs(args.save_dir, exist_ok=True)
    ptb_tag = str(args.ptb).replace(".", "p")
    experimental_tag = ""
    if args.fusion_rule != "paper":
        experimental_tag += f"_fusion_{args.fusion_rule}"
    if args.multiscale_cross_view:
        experimental_tag += "_multiscale_cross_view"
    if args.strict_negatives:
        experimental_tag += "_strict_negatives"
    if args.high_recon_target != "residual":
        experimental_tag += f"_high_target_{args.high_recon_target}"
    if args.edge_weight_mode != "confidence":
        experimental_tag += f"_edge_{args.edge_weight_mode}"
    if args.multiscale_inference != "fused":
        experimental_tag += f"_multiscale_{args.multiscale_inference}"
    args.save_path = (
        f"{args.save_dir}/freq_robust_{args.dataset}_{args.attack}_"
        f"{ptb_tag}_{args.ablation}_seed{args.seed}{experimental_tag}.pt"
    )
    print(tab_printer(args))

    set_seed(args.seed)
    device = (f"cuda:{args.device}" if args.device >= 0 and torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")
    track_resources = (
        args.attack == "clean" and args.ablation == "full"
        and args.eval_only_checkpoint is None
    )
    rss_monitor = PeakRSSMonitor() if track_resources else None
    if rss_monitor is not None:
        rss_monitor.start()
    if track_resources and device.startswith("cuda"):
        torch.cuda.reset_peak_memory_stats()

    transform = T.Compose([T.ToUndirected(), T.ToDevice(device)])

    # 加载（可能含攻击的）图数据
    data = get_dataset_prognn("data/", args, transform=transform)
    print(f"Graph: {data.num_nodes} nodes, {data.edge_index.size(1)} edges, " f"{data.num_features} features")

    # 构建 FreqRobustGMAE
    model = FreqRobustGMAE(in_channels=data.num_features, hidden_channels=args.hidden_channels,  # 分支内部隐层（未来可扩展）
        out_channels=args.hidden_channels,     # 每分支输出维度
        mask_rate=args.mask_rate, K=args.K, J=args.J,
        dropout=args.dropout, lambda_c=args.lambda_c, lambda_b=args.lambda_b, temperature=args.temperature,
        ablation=args.ablation,
        fusion_rule=args.fusion_rule,
        multiscale_cross_view=args.multiscale_cross_view,
        multiscale_inference=args.multiscale_inference,
        strict_negatives=args.strict_negatives,
        high_recon_target=args.high_recon_target,
        edge_weight_mode=args.edge_weight_mode,
    ).to(device)

    total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Trainable parameters: {total_params:,}")
    if args.fusion_diagnostics:
        print("[FusionDiagnostic] " + json.dumps(
            model.fusion_diagnostics(data.x, data.edge_index),
            sort_keys=True,
        ))

    # Pre-train by default; use one fixed checkpoint to isolate inference-only
    # fusion changes when explicitly requested.
    if args.eval_only_checkpoint is None:
        pretrain_start_time = time.perf_counter()
        pretrain(model, data, args, device=device)
        if track_resources and device.startswith("cuda"):
            torch.cuda.synchronize()
        pretrain_seconds = time.perf_counter() - pretrain_start_time
    else:
        state_dict = torch.load(
            args.eval_only_checkpoint, map_location=device, weights_only=True
        )
        model.load_state_dict(state_dict)
        pretrain_seconds = 0.0
        print(f"[EvalOnly] loaded checkpoint: {args.eval_only_checkpoint}")

    # 节点分类评估
    # model.load_state_dict(torch.load(args.save_path))
    model.eval()
    evaluation_start_time = time.perf_counter()
    train_nodeclas(model, data, args, device=device)
    if track_resources and device.startswith("cuda"):
        torch.cuda.synchronize()
    evaluation_seconds = time.perf_counter() - evaluation_start_time
    total_seconds = time.perf_counter() - total_start_time
    if track_resources:
        if rss_monitor is not None:
            rss_monitor.stop()
        peak_cuda_mb = (
            torch.cuda.max_memory_allocated() / (1024 ** 2)
            if device.startswith("cuda") else 0.0
        )
        peak_cuda_reserved_mb = (
            torch.cuda.max_memory_reserved() / (1024 ** 2)
            if device.startswith("cuda") else 0.0
        )
        peak_rss_mb = rss_monitor.peak / (1024 ** 2) if rss_monitor is not None else 0.0
        rss_delta_mb = (
            (rss_monitor.peak - rss_monitor.baseline) / (1024 ** 2)
            if rss_monitor is not None else 0.0
        )
        print(
            "[Resource] "
            f"pretrain_seconds={pretrain_seconds:.3f}, "
            f"evaluation_seconds={evaluation_seconds:.3f}, "
            f"total_seconds={total_seconds:.3f}, "
            f"peak_cuda_memory_mb={peak_cuda_mb:.3f}, "
            f"peak_cuda_reserved_mb={peak_cuda_reserved_mb:.3f}, "
            f"peak_rss_mb={peak_rss_mb:.3f}, "
            f"rss_delta_mb={rss_delta_mb:.3f}"
        )


if __name__ == "__main__":
    main()
