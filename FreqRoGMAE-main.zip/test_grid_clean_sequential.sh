#!/usr/bin/env bash
# ============================================================================
# test_grid_clean_sequential.sh
# FreqRobustGMAE clean 图超参数全量网格搜索（严格串行版本）
#
# 数据集：Photo、Computers
# 攻击：clean
# 参数：K、J、hidden_channels、dropout、mask_rate、lr
#
# 特性：
#   1. 所有实验严格串行执行，不使用后台任务或并行工具；
#   2. 使用 flock 防止同一 GPU 上重复启动本脚本；
#   3. 每个参数组合独立保存日志；
#   4. 成功实验生成 .done 标记，重新运行时自动跳过；
#   5. 失败实验只写一条 FAILED，不会继续错误解析日志；
#   6. 限制 BLAS/OpenMP 线程数，降低 CPU 和内存压力。
#
# 使用方式：
#   chmod +x test_grid_clean_sequential.sh
#   GPU_ID=0 nohup bash test_grid_clean_sequential.sh \
#       > results_grid_clean/grid_clean.out 2>&1 &
#
# 可选环境变量：
#   GPU_ID=0                 指定物理 GPU，默认 0
#   PYTHON_BIN=python        Python 可执行文件，默认 python
#   CPU_THREADS=4            每个训练进程允许的 CPU 线程数，默认 4
#   SKIP_COMPLETED=1         是否跳过已有 .done 的实验，默认 1
# ============================================================================

set -uo pipefail

# ---------------------------------------------------------------------------
# 运行环境
# ---------------------------------------------------------------------------
GPU_ID="${GPU_ID:-0}"
PYTHON_BIN="${PYTHON_BIN:-python}"
CPU_THREADS="${CPU_THREADS:-4}"
SKIP_COMPLETED="${SKIP_COMPLETED:-1}"

# CUDA_VISIBLE_DEVICES 设置后，Python 程序内部应继续使用 --device 0。
export CUDA_VISIBLE_DEVICES="${GPU_ID}"

# 控制单个 Python 进程内部的 CPU 线程数量，防止线程过多占用内存。
export OMP_NUM_THREADS="${CPU_THREADS}"
export MKL_NUM_THREADS="${CPU_THREADS}"
export OPENBLAS_NUM_THREADS="${CPU_THREADS}"
export NUMEXPR_NUM_THREADS="${CPU_THREADS}"
export PYTHONUNBUFFERED=1

if ! command -v "${PYTHON_BIN}" >/dev/null 2>&1; then
    echo "[ERROR] 找不到 Python：${PYTHON_BIN}"
    exit 1
fi

if ! command -v flock >/dev/null 2>&1; then
    echo "[ERROR] 系统未安装 flock，无法启用单实例保护。"
    echo "Ubuntu/Debian 通常可通过 util-linux 软件包提供 flock。"
    exit 1
fi

if [ ! -f "train_freq_robust.py" ]; then
    echo "[ERROR] 当前目录下不存在 train_freq_robust.py。"
    echo "请先 cd 到 FreqRoGMAE 项目根目录后再运行。"
    exit 1
fi

# ---------------------------------------------------------------------------
# 单 GPU 单实例锁
#
# 只有使用相同锁文件约定的任务才能相互排斥。若还有其他训练脚本，也建议
# 让它们使用 /tmp/freqrogmae_gpu_<GPU_ID>.lock。
# ---------------------------------------------------------------------------
LOCK_FILE="/tmp/freqrogmae_gpu_${GPU_ID}.lock"
exec 9>"${LOCK_FILE}"

if ! flock -n 9; then
    echo "[ERROR] GPU ${GPU_ID} 上已经有一个 FreqRoGMAE 网格任务持有锁。"
    echo "锁文件：${LOCK_FILE}"
    echo "请先使用以下命令检查现有任务："
    echo "  pgrep -af 'test_grid_clean|train_freq_robust.py'"
    exit 1
fi

# 脚本退出时文件描述符会自动关闭并释放锁；锁文件本身可以保留。

# ---------------------------------------------------------------------------
# 超参数候选值
# ---------------------------------------------------------------------------
K_VALUES=(1 3 5 7)
J_VALUES=(1 2 3 4)
HIDDEN_VALUES=(64 128 256 512)
DROPOUT_VALUES=(0.3 0.5 0.7)
MASK_RATE_VALUES=(0.3 0.5 0.7)
LR_VALUES=(0.0005 0.001 0.003 0.005)

DATASETS=("Photo" "Computers")

# ---------------------------------------------------------------------------
# 公共固定参数
# ---------------------------------------------------------------------------
RUNS=5
EPOCHS=1500
EVAL_PERIOD=50
SEED=2026

RESULT_ROOT="results_grid_clean"
mkdir -p "${RESULT_ROOT}"

# 4*4*4*3*3*4=2304 个组合/数据集，共 4608 个实验。
COMBINATIONS_PER_DATASET=$((
    ${#K_VALUES[@]}
    * ${#J_VALUES[@]}
    * ${#HIDDEN_VALUES[@]}
    * ${#DROPOUT_VALUES[@]}
    * ${#MASK_RATE_VALUES[@]}
    * ${#LR_VALUES[@]}
))
TOTAL_EXPERIMENTS=$((COMBINATIONS_PER_DATASET * ${#DATASETS[@]}))

CURRENT_INDEX=0
SUCCESS_COUNT=0
FAILED_COUNT=0
SKIPPED_COUNT=0

# ---------------------------------------------------------------------------
# 安全终止提示
# ---------------------------------------------------------------------------
handle_signal() {
    echo
    echo "[STOP] 收到终止信号，脚本将在当前前台训练进程结束后退出。"
    echo "已完成成功=${SUCCESS_COUNT}，失败=${FAILED_COUNT}，跳过=${SKIPPED_COUNT}。"
    exit 130
}

trap handle_signal INT TERM

# ---------------------------------------------------------------------------
# 初始化数据集汇总 CSV
# ---------------------------------------------------------------------------
init_summary_file() {
    local dataset="$1"
    local summary_file="${RESULT_ROOT}/${dataset}_summary.csv"

    if [ ! -f "${summary_file}" ]; then
        echo "Dataset,K,J,Hidden_Channels,Dropout,Mask_Rate,LR,Status,Result_Log,Log_File" \
            > "${summary_file}"
    fi
}

# ---------------------------------------------------------------------------
# 单次实验
# ---------------------------------------------------------------------------
run_one() {
    local dataset="$1"
    local K="$2"
    local J="$3"
    local hidden="$4"
    local dropout="$5"
    local mask_rate="$6"
    local lr="$7"
    local tag="$8"

    local out_dir="${RESULT_ROOT}/${dataset}/clean"
    local log_file="${out_dir}/${tag}.log"
    local done_file="${out_dir}/${tag}.done"
    local summary_file="${RESULT_ROOT}/${dataset}_summary.csv"

    mkdir -p "${out_dir}"
    CURRENT_INDEX=$((CURRENT_INDEX + 1))

    echo "========================================================================"
    echo ">>> [${CURRENT_INDEX}/${TOTAL_EXPERIMENTS}] dataset=${dataset} attack=clean"
    echo ">>> K=${K} J=${J} hidden=${hidden} dropout=${dropout} mask=${mask_rate} lr=${lr}"

    # 已经成功完成的组合直接跳过，便于服务器任务中断后续跑。
    if [ "${SKIP_COMPLETED}" = "1" ] && [ -f "${done_file}" ]; then
        echo "    [SKIPPED] 已存在完成标记：${done_file}"
        SKIPPED_COUNT=$((SKIPPED_COUNT + 1))
        return 0
    fi

    # Bash 数组可避免参数中的空格或特殊字符被错误拆分。
    local cmd=(
        "${PYTHON_BIN}"
        train_freq_robust.py
        --dataset "${dataset}"
        --attack clean
        --K "${K}"
        --J "${J}"
        --hidden_channels "${hidden}"
        --dropout "${dropout}"
        --mask_rate "${mask_rate}"
        --lr "${lr}"
        --epochs "${EPOCHS}"
        --eval_period "${EVAL_PERIOD}"
        --runs "${RUNS}"
        --seed "${SEED}"
        --device 0
    )

    echo "    日志：${log_file}"

    # 重要：此处没有 '&'，Python 是前台执行，因此下一个实验必须等待它结束。
    if "${cmd[@]}" > "${log_file}" 2>&1; then
        local acc_line
        local csv_acc_line
        acc_line=$(grep "Node Classification" "${log_file}" | tail -n 1 || true)

        if [ -z "${acc_line}" ]; then
            echo "    [NO_RESULT] Python 正常退出，但日志中没有 Node Classification。"
            echo "${dataset},${K},${J},${hidden},${dropout},${mask_rate},${lr},NO_RESULT,\"NO_RESULT_LINE\",\"${log_file}\"" \
                >> "${summary_file}"
            FAILED_COUNT=$((FAILED_COUNT + 1))
            return 1
        fi

        # CSV 中的双引号使用两个双引号转义。
        csv_acc_line="${acc_line//\"/\"\"}"
        echo "    [OK] ${acc_line}"
        echo "${dataset},${K},${J},${hidden},${dropout},${mask_rate},${lr},SUCCESS,\"${csv_acc_line}\",\"${log_file}\"" \
            >> "${summary_file}"

        # 只有成功获得最终分类结果才写入完成标记。
        printf '%s\n' "${acc_line}" > "${done_file}"
        SUCCESS_COUNT=$((SUCCESS_COUNT + 1))
        return 0
    else
        local exit_code=$?
        echo "    [FAILED] Python 退出码=${exit_code}，请查看：${log_file}"
        echo "${dataset},${K},${J},${hidden},${dropout},${mask_rate},${lr},FAILED,\"EXIT_CODE_${exit_code}\",\"${log_file}\"" \
            >> "${summary_file}"
        FAILED_COUNT=$((FAILED_COUNT + 1))
        return "${exit_code}"
    fi
}

# ---------------------------------------------------------------------------
# 单个数据集的完整网格
# ---------------------------------------------------------------------------
run_grid_suite() {
    local dataset="$1"
    local K
    local J
    local hidden
    local dropout
    local mask_rate
    local lr
    local tag

    init_summary_file "${dataset}"

    for K in "${K_VALUES[@]}"; do
        for J in "${J_VALUES[@]}"; do
            for hidden in "${HIDDEN_VALUES[@]}"; do
                for dropout in "${DROPOUT_VALUES[@]}"; do
                    for mask_rate in "${MASK_RATE_VALUES[@]}"; do
                        for lr in "${LR_VALUES[@]}"; do
                            tag="K${K}_J${J}_h${hidden}_d${dropout}_m${mask_rate}_lr${lr}"

                            # 失败不会中断整个网格扫描。
                            run_one \
                                "${dataset}" \
                                "${K}" \
                                "${J}" \
                                "${hidden}" \
                                "${dropout}" \
                                "${mask_rate}" \
                                "${lr}" \
                                "${tag}" || true
                        done
                    done
                done
            done
        done
    done
}

# ---------------------------------------------------------------------------
# 主程序
# ---------------------------------------------------------------------------
TOTAL_START=$(date +%s)

echo "========================================================================"
echo "FreqRobustGMAE Clean Grid Search - Strictly Sequential"
echo "========================================================================"
echo "GPU_ID                : ${GPU_ID}"
echo "CUDA_VISIBLE_DEVICES  : ${CUDA_VISIBLE_DEVICES}"
echo "Python                : ${PYTHON_BIN}"
echo "CPU threads/process   : ${CPU_THREADS}"
echo "Epochs/experiment     : ${EPOCHS}"
echo "Runs/experiment       : ${RUNS}"
echo "Experiments/dataset   : ${COMBINATIONS_PER_DATASET}"
echo "Total experiments     : ${TOTAL_EXPERIMENTS}"
echo "Result directory      : ${RESULT_ROOT}"
echo "Lock file             : ${LOCK_FILE}"
echo "========================================================================"

for dataset in "${DATASETS[@]}"; do
    echo
    echo "########################################################################"
    echo "Dataset: ${dataset} (Clean)"
    echo "########################################################################"
    run_grid_suite "${dataset}"
done

TOTAL_END=$(date +%s)
TOTAL_SECONDS=$((TOTAL_END - TOTAL_START))
TOTAL_MINUTES=$((TOTAL_SECONDS / 60))
TOTAL_HOURS=$((TOTAL_SECONDS / 3600))

echo
echo "========================================================================"
echo "全部 Clean 网格搜索实验完成"
echo "========================================================================"
echo "总耗时       : ${TOTAL_MINUTES} 分钟（约 ${TOTAL_HOURS} 小时）"
echo "成功         : ${SUCCESS_COUNT}"
echo "失败/无结果  : ${FAILED_COUNT}"
echo "断点跳过     : ${SKIPPED_COUNT}"
echo "完整日志目录 : ${RESULT_ROOT}/"
echo "汇总 CSV     : ${RESULT_ROOT}/Photo_summary.csv"
echo "               ${RESULT_ROOT}/Computers_summary.csv"
echo "========================================================================"
